﻿namespace Gen2ExtensionsDemo
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gpb_rs232 = new System.Windows.Forms.GroupBox();
            this.btDisConnect232 = new System.Windows.Forms.Button();
            this.btConnect232 = new System.Windows.Forms.Button();
            this.ComboBox_baud2 = new System.Windows.Forms.ComboBox();
            this.label47 = new System.Windows.Forms.Label();
            this.ComboBox_COM = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkant4 = new System.Windows.Forms.CheckBox();
            this.checkant3 = new System.Windows.Forms.CheckBox();
            this.checkant2 = new System.Windows.Forms.CheckBox();
            this.checkant1 = new System.Windows.Forms.CheckBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.com_S = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.com_Q = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.lxLedControl4 = new LxControl.LxLedControl();
            this.button2 = new System.Windows.Forms.Button();
            this.lxLedControl3 = new LxControl.LxLedControl();
            this.label5 = new System.Windows.Forms.Label();
            this.lxLedControl2 = new LxControl.LxLedControl();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lxLedControl1 = new LxControl.LxLedControl();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox66 = new System.Windows.Forms.GroupBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button13 = new System.Windows.Forms.Button();
            this.txt_success_rate = new System.Windows.Forms.Label();
            this.lxLed_avgtime = new LxControl.LxLedControl();
            this.label29 = new System.Windows.Forms.Label();
            this.lxLed_maxtuntime = new LxControl.LxLedControl();
            this.label27 = new System.Windows.Forms.Label();
            this.lxLed_lostcount = new LxControl.LxLedControl();
            this.label28 = new System.Windows.Forms.Label();
            this.lxLed_testcount = new LxControl.LxLedControl();
            this.label25 = new System.Windows.Forms.Label();
            this.lxLed_runtime = new LxControl.LxLedControl();
            this.label26 = new System.Windows.Forms.Label();
            this.lxLed_epccount = new LxControl.LxLedControl();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txt_maxscantime = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txt_testepccount = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txt_scaninterval = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txt_scancount = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.txt_authdata = new System.Windows.Forms.TextBox();
            this.txt_challenge = new System.Windows.Forms.TextBox();
            this.button15 = new System.Windows.Forms.Button();
            this.label208 = new System.Windows.Forms.Label();
            this.label207 = new System.Windows.Forms.Label();
            this.com_epc1 = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.com_epc2 = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txt_pro_password = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.text_pro_pwd = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.rb_pro_en = new System.Windows.Forms.RadioButton();
            this.rb_pro_disabe = new System.Windows.Forms.RadioButton();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.StatusBar1 = new System.Windows.Forms.StatusBar();
            this.TStatusPanel = new System.Windows.Forms.StatusBarPanel();
            this.Port = new System.Windows.Forms.StatusBarPanel();
            this.Manufacturername = new System.Windows.Forms.StatusBarPanel();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.gpb_DBM = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.ComboBox_PowerDbm = new System.Windows.Forms.ComboBox();
            this.BT_DBM = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.textBox_pc = new System.Windows.Forms.TextBox();
            this.checkBox_pc = new System.Windows.Forms.CheckBox();
            this.btWrite = new System.Windows.Forms.Button();
            this.btRead = new System.Windows.Forms.Button();
            this.text_WriteData = new System.Windows.Forms.TextBox();
            this.text_AccessCode2 = new System.Windows.Forms.TextBox();
            this.text_RWlen = new System.Windows.Forms.TextBox();
            this.text_WordPtr = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.C_User = new System.Windows.Forms.RadioButton();
            this.C_TID = new System.Windows.Forms.RadioButton();
            this.C_EPC = new System.Windows.Forms.RadioButton();
            this.C_Reserve = new System.Windows.Forms.RadioButton();
            this.comboBox_EPC = new System.Windows.Forms.ComboBox();
            this.label34 = new System.Windows.Forms.Label();
            this.gpb_rs232.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lxLedControl4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLedControl3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLedControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLedControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox66.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lxLed_avgtime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLed_maxtuntime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLed_lostcount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLed_testcount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLed_runtime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLed_epccount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TStatusPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Port)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Manufacturername)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.gpb_DBM.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.SuspendLayout();
            // 
            // gpb_rs232
            // 
            this.gpb_rs232.Controls.Add(this.btDisConnect232);
            this.gpb_rs232.Controls.Add(this.btConnect232);
            this.gpb_rs232.Controls.Add(this.ComboBox_baud2);
            this.gpb_rs232.Controls.Add(this.label47);
            this.gpb_rs232.Controls.Add(this.ComboBox_COM);
            this.gpb_rs232.Controls.Add(this.label3);
            this.gpb_rs232.Location = new System.Drawing.Point(7, 78);
            this.gpb_rs232.Name = "gpb_rs232";
            this.gpb_rs232.Size = new System.Drawing.Size(343, 69);
            this.gpb_rs232.TabIndex = 4;
            this.gpb_rs232.TabStop = false;
            this.gpb_rs232.Text = "RS232";
            // 
            // btDisConnect232
            // 
            this.btDisConnect232.Enabled = false;
            this.btDisConnect232.Location = new System.Drawing.Point(234, 41);
            this.btDisConnect232.Name = "btDisConnect232";
            this.btDisConnect232.Size = new System.Drawing.Size(90, 23);
            this.btDisConnect232.TabIndex = 20;
            this.btDisConnect232.Text = "DisConnect";
            this.btDisConnect232.UseVisualStyleBackColor = true;
            this.btDisConnect232.Click += new System.EventHandler(this.btDisConnect232_Click);
            // 
            // btConnect232
            // 
            this.btConnect232.Location = new System.Drawing.Point(234, 13);
            this.btConnect232.Name = "btConnect232";
            this.btConnect232.Size = new System.Drawing.Size(90, 23);
            this.btConnect232.TabIndex = 19;
            this.btConnect232.Text = "Connect";
            this.btConnect232.UseVisualStyleBackColor = true;
            this.btConnect232.Click += new System.EventHandler(this.btConnect232_Click);
            // 
            // ComboBox_baud2
            // 
            this.ComboBox_baud2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_baud2.FormattingEnabled = true;
            this.ComboBox_baud2.Items.AddRange(new object[] {
            "9600bps",
            "19200bps",
            "38400bps",
            "57600bps",
            "115200bps"});
            this.ComboBox_baud2.Location = new System.Drawing.Point(96, 43);
            this.ComboBox_baud2.Name = "ComboBox_baud2";
            this.ComboBox_baud2.Size = new System.Drawing.Size(121, 20);
            this.ComboBox_baud2.TabIndex = 18;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(29, 48);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(59, 12);
            this.label47.TabIndex = 17;
            this.label47.Text = "BaudRate:";
            // 
            // ComboBox_COM
            // 
            this.ComboBox_COM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_COM.FormattingEnabled = true;
            this.ComboBox_COM.Items.AddRange(new object[] {
            "COM1",
            "COM2",
            "COM3",
            "COM4",
            "COM5",
            "COM6",
            "COM7",
            "COM8",
            "COM9",
            "COM10",
            "COM11",
            "COM12",
            "COM13",
            "COM14",
            "COM15",
            "COM16",
            "COM17",
            "COM18",
            "COM19",
            "COM20"});
            this.ComboBox_COM.Location = new System.Drawing.Point(96, 15);
            this.ComboBox_COM.Name = "ComboBox_COM";
            this.ComboBox_COM.Size = new System.Drawing.Size(121, 20);
            this.ComboBox_COM.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 12);
            this.label3.TabIndex = 13;
            this.label3.Text = "SerialPort:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkant4);
            this.groupBox1.Controls.Add(this.checkant3);
            this.groupBox1.Controls.Add(this.checkant2);
            this.groupBox1.Controls.Add(this.checkant1);
            this.groupBox1.Location = new System.Drawing.Point(357, 79);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(288, 67);
            this.groupBox1.TabIndex = 93;
            this.groupBox1.TabStop = false;
            // 
            // checkant4
            // 
            this.checkant4.AutoSize = true;
            this.checkant4.Location = new System.Drawing.Point(234, 31);
            this.checkant4.Name = "checkant4";
            this.checkant4.Size = new System.Drawing.Size(48, 16);
            this.checkant4.TabIndex = 104;
            this.checkant4.Text = "ANT4";
            this.checkant4.UseVisualStyleBackColor = true;
            // 
            // checkant3
            // 
            this.checkant3.AutoSize = true;
            this.checkant3.Location = new System.Drawing.Point(169, 31);
            this.checkant3.Name = "checkant3";
            this.checkant3.Size = new System.Drawing.Size(48, 16);
            this.checkant3.TabIndex = 103;
            this.checkant3.Text = "ANT3";
            this.checkant3.UseVisualStyleBackColor = true;
            // 
            // checkant2
            // 
            this.checkant2.AutoSize = true;
            this.checkant2.Location = new System.Drawing.Point(96, 31);
            this.checkant2.Name = "checkant2";
            this.checkant2.Size = new System.Drawing.Size(48, 16);
            this.checkant2.TabIndex = 102;
            this.checkant2.Text = "ANT2";
            this.checkant2.UseVisualStyleBackColor = true;
            // 
            // checkant1
            // 
            this.checkant1.AutoSize = true;
            this.checkant1.Checked = true;
            this.checkant1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkant1.Location = new System.Drawing.Point(20, 31);
            this.checkant1.Name = "checkant1";
            this.checkant1.Size = new System.Drawing.Size(48, 16);
            this.checkant1.TabIndex = 101;
            this.checkant1.Text = "ANT1";
            this.checkant1.UseVisualStyleBackColor = true;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(295, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(477, 29);
            this.label1.TabIndex = 94;
            this.label1.Text = "RoyalRay Gen2 Extensions Demo";
            // 
            // com_S
            // 
            this.com_S.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.com_S.FormattingEnabled = true;
            this.com_S.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3"});
            this.com_S.Location = new System.Drawing.Point(713, 123);
            this.com_S.Name = "com_S";
            this.com_S.Size = new System.Drawing.Size(59, 20);
            this.com_S.TabIndex = 106;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(653, 127);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(53, 12);
            this.label32.TabIndex = 105;
            this.label32.Text = "Session:";
            // 
            // com_Q
            // 
            this.com_Q.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.com_Q.FormattingEnabled = true;
            this.com_Q.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.com_Q.Location = new System.Drawing.Point(713, 94);
            this.com_Q.Name = "com_Q";
            this.com_Q.Size = new System.Drawing.Size(59, 20);
            this.com_Q.TabIndex = 104;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(689, 95);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(17, 12);
            this.label31.TabIndex = 103;
            this.label31.Text = "Q:";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Enabled = false;
            this.tabControl1.Location = new System.Drawing.Point(0, 152);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1088, 545);
            this.tabControl1.TabIndex = 107;
            this.tabControl1.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl1_Selecting);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.lxLedControl4);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.lxLedControl3);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.lxLedControl2);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.lxLedControl1);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.groupBox66);
            this.tabPage1.Location = new System.Drawing.Point(4, 21);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1080, 520);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Quieting Inventory(QI)";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(852, 161);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(173, 12);
            this.label6.TabIndex = 121;
            this.label6.Text = "Unique EPC Count(QI Enable):";
            // 
            // lxLedControl4
            // 
            this.lxLedControl4.BackColor = System.Drawing.Color.Transparent;
            this.lxLedControl4.BackColor_1 = System.Drawing.Color.Transparent;
            this.lxLedControl4.BackColor_2 = System.Drawing.Color.DarkRed;
            this.lxLedControl4.BevelRate = 0.5F;
            this.lxLedControl4.BorderColor = System.Drawing.Color.Lavender;
            this.lxLedControl4.BorderWidth = 3;
            this.lxLedControl4.FadedColor = System.Drawing.SystemColors.ControlLight;
            this.lxLedControl4.FocusedBorderColor = System.Drawing.Color.LightCoral;
            this.lxLedControl4.ForeColor = System.Drawing.Color.Crimson;
            this.lxLedControl4.HighlightOpaque = ((byte)(50));
            this.lxLedControl4.Location = new System.Drawing.Point(852, 178);
            this.lxLedControl4.Name = "lxLedControl4";
            this.lxLedControl4.RoundCorner = true;
            this.lxLedControl4.ShowHighlight = true;
            this.lxLedControl4.Size = new System.Drawing.Size(219, 53);
            this.lxLedControl4.TabIndex = 120;
            this.lxLedControl4.Text = "0";
            this.lxLedControl4.TextAlignment = LxControl.LxLedControl.Alignment.Right;
            this.lxLedControl4.TotalCharCount = 8;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(661, 19);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(104, 38);
            this.button2.TabIndex = 119;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lxLedControl3
            // 
            this.lxLedControl3.BackColor = System.Drawing.Color.Transparent;
            this.lxLedControl3.BackColor_1 = System.Drawing.Color.Transparent;
            this.lxLedControl3.BackColor_2 = System.Drawing.Color.DarkRed;
            this.lxLedControl3.BevelRate = 0.5F;
            this.lxLedControl3.BorderColor = System.Drawing.Color.Lavender;
            this.lxLedControl3.BorderWidth = 3;
            this.lxLedControl3.FadedColor = System.Drawing.SystemColors.ControlLight;
            this.lxLedControl3.FocusedBorderColor = System.Drawing.Color.LightCoral;
            this.lxLedControl3.ForeColor = System.Drawing.Color.Purple;
            this.lxLedControl3.HighlightOpaque = ((byte)(50));
            this.lxLedControl3.Location = new System.Drawing.Point(852, 365);
            this.lxLedControl3.Name = "lxLedControl3";
            this.lxLedControl3.RoundCorner = true;
            this.lxLedControl3.ShowHighlight = true;
            this.lxLedControl3.Size = new System.Drawing.Size(219, 53);
            this.lxLedControl3.TabIndex = 118;
            this.lxLedControl3.Text = "0";
            this.lxLedControl3.TextAlignment = LxControl.LxLedControl.Alignment.Right;
            this.lxLedControl3.TotalCharCount = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(852, 350);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 12);
            this.label5.TabIndex = 117;
            this.label5.Text = "Run Time(ms):";
            // 
            // lxLedControl2
            // 
            this.lxLedControl2.BackColor = System.Drawing.Color.Transparent;
            this.lxLedControl2.BackColor_1 = System.Drawing.Color.Transparent;
            this.lxLedControl2.BackColor_2 = System.Drawing.Color.DarkRed;
            this.lxLedControl2.BevelRate = 0.5F;
            this.lxLedControl2.BorderColor = System.Drawing.Color.Lavender;
            this.lxLedControl2.BorderWidth = 3;
            this.lxLedControl2.FadedColor = System.Drawing.SystemColors.ControlLight;
            this.lxLedControl2.FocusedBorderColor = System.Drawing.Color.LightCoral;
            this.lxLedControl2.ForeColor = System.Drawing.Color.Purple;
            this.lxLedControl2.HighlightOpaque = ((byte)(50));
            this.lxLedControl2.Location = new System.Drawing.Point(852, 268);
            this.lxLedControl2.Name = "lxLedControl2";
            this.lxLedControl2.RoundCorner = true;
            this.lxLedControl2.ShowHighlight = true;
            this.lxLedControl2.Size = new System.Drawing.Size(219, 53);
            this.lxLedControl2.TabIndex = 116;
            this.lxLedControl2.Text = "0";
            this.lxLedControl2.TextAlignment = LxControl.LxLedControl.Alignment.Right;
            this.lxLedControl2.TotalCharCount = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(852, 253);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 12);
            this.label4.TabIndex = 115;
            this.label4.Text = "Total EPC Count:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(852, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(179, 12);
            this.label2.TabIndex = 114;
            this.label2.Text = "Unique EPC Count(QI Disable):";
            // 
            // lxLedControl1
            // 
            this.lxLedControl1.BackColor = System.Drawing.Color.Transparent;
            this.lxLedControl1.BackColor_1 = System.Drawing.Color.Transparent;
            this.lxLedControl1.BackColor_2 = System.Drawing.Color.DarkRed;
            this.lxLedControl1.BevelRate = 0.5F;
            this.lxLedControl1.BorderColor = System.Drawing.Color.Lavender;
            this.lxLedControl1.BorderWidth = 3;
            this.lxLedControl1.FadedColor = System.Drawing.SystemColors.ControlLight;
            this.lxLedControl1.FocusedBorderColor = System.Drawing.Color.LightCoral;
            this.lxLedControl1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lxLedControl1.HighlightOpaque = ((byte)(50));
            this.lxLedControl1.Location = new System.Drawing.Point(852, 91);
            this.lxLedControl1.Name = "lxLedControl1";
            this.lxLedControl1.RoundCorner = true;
            this.lxLedControl1.ShowHighlight = true;
            this.lxLedControl1.Size = new System.Drawing.Size(219, 53);
            this.lxLedControl1.TabIndex = 113;
            this.lxLedControl1.Text = "0";
            this.lxLedControl1.TextAlignment = LxControl.LxLedControl.Alignment.Right;
            this.lxLedControl1.TotalCharCount = 8;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(2, 62);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(844, 455);
            this.dataGridView1.TabIndex = 112;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(530, 19);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 38);
            this.button1.TabIndex = 111;
            this.button1.Text = "Start";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox66
            // 
            this.groupBox66.Controls.Add(this.radioButton2);
            this.groupBox66.Controls.Add(this.radioButton1);
            this.groupBox66.Controls.Add(this.button18);
            this.groupBox66.Controls.Add(this.button17);
            this.groupBox66.Location = new System.Drawing.Point(5, 7);
            this.groupBox66.Name = "groupBox66";
            this.groupBox66.Size = new System.Drawing.Size(495, 57);
            this.groupBox66.TabIndex = 110;
            this.groupBox66.TabStop = false;
            this.groupBox66.Text = "Tag Quieting";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(128, 25);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(65, 16);
            this.radioButton2.TabIndex = 12;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Disable";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(24, 25);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(59, 16);
            this.radioButton1.TabIndex = 11;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Enable";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(409, 22);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(75, 23);
            this.button18.TabIndex = 10;
            this.button18.Text = "Get";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(329, 22);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(75, 23);
            this.button17.TabIndex = 9;
            this.button17.Text = "Set";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button13);
            this.tabPage2.Controls.Add(this.txt_success_rate);
            this.tabPage2.Controls.Add(this.lxLed_avgtime);
            this.tabPage2.Controls.Add(this.label29);
            this.tabPage2.Controls.Add(this.lxLed_maxtuntime);
            this.tabPage2.Controls.Add(this.label27);
            this.tabPage2.Controls.Add(this.lxLed_lostcount);
            this.tabPage2.Controls.Add(this.label28);
            this.tabPage2.Controls.Add(this.lxLed_testcount);
            this.tabPage2.Controls.Add(this.label25);
            this.tabPage2.Controls.Add(this.lxLed_runtime);
            this.tabPage2.Controls.Add(this.label26);
            this.tabPage2.Controls.Add(this.lxLed_epccount);
            this.tabPage2.Controls.Add(this.label24);
            this.tabPage2.Controls.Add(this.label23);
            this.tabPage2.Controls.Add(this.txt_maxscantime);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.txt_testepccount);
            this.tabPage2.Controls.Add(this.label22);
            this.tabPage2.Controls.Add(this.txt_scaninterval);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.txt_scancount);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Controls.Add(this.button7);
            this.tabPage2.Controls.Add(this.button8);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 21);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1080, 520);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Impinj Inventory Mode";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(897, 452);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(121, 32);
            this.button13.TabIndex = 152;
            this.button13.Text = "View statistics";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // txt_success_rate
            // 
            this.txt_success_rate.AutoSize = true;
            this.txt_success_rate.Font = new System.Drawing.Font("宋体", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_success_rate.ForeColor = System.Drawing.Color.Red;
            this.txt_success_rate.Location = new System.Drawing.Point(902, 396);
            this.txt_success_rate.Name = "txt_success_rate";
            this.txt_success_rate.Size = new System.Drawing.Size(0, 33);
            this.txt_success_rate.TabIndex = 151;
            // 
            // lxLed_avgtime
            // 
            this.lxLed_avgtime.BackColor = System.Drawing.Color.Transparent;
            this.lxLed_avgtime.BackColor_1 = System.Drawing.Color.Transparent;
            this.lxLed_avgtime.BackColor_2 = System.Drawing.Color.DarkRed;
            this.lxLed_avgtime.BevelRate = 0.5F;
            this.lxLed_avgtime.BorderColor = System.Drawing.Color.Lavender;
            this.lxLed_avgtime.BorderWidth = 3;
            this.lxLed_avgtime.FadedColor = System.Drawing.SystemColors.ControlLight;
            this.lxLed_avgtime.FocusedBorderColor = System.Drawing.Color.LightCoral;
            this.lxLed_avgtime.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lxLed_avgtime.HighlightOpaque = ((byte)(50));
            this.lxLed_avgtime.Location = new System.Drawing.Point(897, 333);
            this.lxLed_avgtime.Name = "lxLed_avgtime";
            this.lxLed_avgtime.RoundCorner = true;
            this.lxLed_avgtime.ShowHighlight = true;
            this.lxLed_avgtime.Size = new System.Drawing.Size(121, 22);
            this.lxLed_avgtime.TabIndex = 150;
            this.lxLed_avgtime.Text = "0";
            this.lxLed_avgtime.TextAlignment = LxControl.LxLedControl.Alignment.Right;
            this.lxLed_avgtime.TotalCharCount = 10;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(769, 406);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(113, 12);
            this.label29.TabIndex = 149;
            this.label29.Text = "Read Success Rate:";
            // 
            // lxLed_maxtuntime
            // 
            this.lxLed_maxtuntime.BackColor = System.Drawing.Color.Transparent;
            this.lxLed_maxtuntime.BackColor_1 = System.Drawing.Color.Transparent;
            this.lxLed_maxtuntime.BackColor_2 = System.Drawing.Color.DarkRed;
            this.lxLed_maxtuntime.BevelRate = 0.5F;
            this.lxLed_maxtuntime.BorderColor = System.Drawing.Color.Lavender;
            this.lxLed_maxtuntime.BorderWidth = 3;
            this.lxLed_maxtuntime.FadedColor = System.Drawing.SystemColors.ControlLight;
            this.lxLed_maxtuntime.FocusedBorderColor = System.Drawing.Color.LightCoral;
            this.lxLed_maxtuntime.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lxLed_maxtuntime.HighlightOpaque = ((byte)(50));
            this.lxLed_maxtuntime.Location = new System.Drawing.Point(897, 364);
            this.lxLed_maxtuntime.Name = "lxLed_maxtuntime";
            this.lxLed_maxtuntime.RoundCorner = true;
            this.lxLed_maxtuntime.ShowHighlight = true;
            this.lxLed_maxtuntime.Size = new System.Drawing.Size(121, 22);
            this.lxLed_maxtuntime.TabIndex = 148;
            this.lxLed_maxtuntime.Text = "0";
            this.lxLed_maxtuntime.TextAlignment = LxControl.LxLedControl.Alignment.Right;
            this.lxLed_maxtuntime.TotalCharCount = 10;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(775, 369);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(107, 12);
            this.label27.TabIndex = 147;
            this.label27.Text = "Max Run Time(ms):";
            // 
            // lxLed_lostcount
            // 
            this.lxLed_lostcount.BackColor = System.Drawing.Color.Transparent;
            this.lxLed_lostcount.BackColor_1 = System.Drawing.Color.Transparent;
            this.lxLed_lostcount.BackColor_2 = System.Drawing.Color.DarkRed;
            this.lxLed_lostcount.BevelRate = 0.5F;
            this.lxLed_lostcount.BorderColor = System.Drawing.Color.Lavender;
            this.lxLed_lostcount.BorderWidth = 3;
            this.lxLed_lostcount.FadedColor = System.Drawing.SystemColors.ControlLight;
            this.lxLed_lostcount.FocusedBorderColor = System.Drawing.Color.LightCoral;
            this.lxLed_lostcount.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lxLed_lostcount.HighlightOpaque = ((byte)(50));
            this.lxLed_lostcount.Location = new System.Drawing.Point(897, 300);
            this.lxLed_lostcount.Name = "lxLed_lostcount";
            this.lxLed_lostcount.RoundCorner = true;
            this.lxLed_lostcount.ShowHighlight = true;
            this.lxLed_lostcount.Size = new System.Drawing.Size(121, 22);
            this.lxLed_lostcount.TabIndex = 146;
            this.lxLed_lostcount.Text = "0";
            this.lxLed_lostcount.TextAlignment = LxControl.LxLedControl.Alignment.Right;
            this.lxLed_lostcount.TotalCharCount = 10;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(775, 338);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(83, 12);
            this.label28.TabIndex = 145;
            this.label28.Text = "AVG Time(ms):";
            // 
            // lxLed_testcount
            // 
            this.lxLed_testcount.BackColor = System.Drawing.Color.Transparent;
            this.lxLed_testcount.BackColor_1 = System.Drawing.Color.Transparent;
            this.lxLed_testcount.BackColor_2 = System.Drawing.Color.DarkRed;
            this.lxLed_testcount.BevelRate = 0.5F;
            this.lxLed_testcount.BorderColor = System.Drawing.Color.Lavender;
            this.lxLed_testcount.BorderWidth = 3;
            this.lxLed_testcount.FadedColor = System.Drawing.SystemColors.ControlLight;
            this.lxLed_testcount.FocusedBorderColor = System.Drawing.Color.LightCoral;
            this.lxLed_testcount.ForeColor = System.Drawing.Color.Red;
            this.lxLed_testcount.HighlightOpaque = ((byte)(50));
            this.lxLed_testcount.Location = new System.Drawing.Point(897, 265);
            this.lxLed_testcount.Name = "lxLed_testcount";
            this.lxLed_testcount.RoundCorner = true;
            this.lxLed_testcount.ShowHighlight = true;
            this.lxLed_testcount.Size = new System.Drawing.Size(121, 22);
            this.lxLed_testcount.TabIndex = 144;
            this.lxLed_testcount.Text = "0";
            this.lxLed_testcount.TextAlignment = LxControl.LxLedControl.Alignment.Right;
            this.lxLed_testcount.TotalCharCount = 10;
            this.lxLed_testcount.Click += new System.EventHandler(this.lxLedControl10_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(775, 305);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(71, 12);
            this.label25.TabIndex = 143;
            this.label25.Text = "Lost Count:";
            this.label25.Click += new System.EventHandler(this.label25_Click);
            // 
            // lxLed_runtime
            // 
            this.lxLed_runtime.BackColor = System.Drawing.Color.Transparent;
            this.lxLed_runtime.BackColor_1 = System.Drawing.Color.Transparent;
            this.lxLed_runtime.BackColor_2 = System.Drawing.Color.DarkRed;
            this.lxLed_runtime.BevelRate = 0.5F;
            this.lxLed_runtime.BorderColor = System.Drawing.Color.Lavender;
            this.lxLed_runtime.BorderWidth = 3;
            this.lxLed_runtime.FadedColor = System.Drawing.SystemColors.ControlLight;
            this.lxLed_runtime.FocusedBorderColor = System.Drawing.Color.LightCoral;
            this.lxLed_runtime.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lxLed_runtime.HighlightOpaque = ((byte)(50));
            this.lxLed_runtime.Location = new System.Drawing.Point(897, 232);
            this.lxLed_runtime.Name = "lxLed_runtime";
            this.lxLed_runtime.RoundCorner = true;
            this.lxLed_runtime.ShowHighlight = true;
            this.lxLed_runtime.Size = new System.Drawing.Size(121, 22);
            this.lxLed_runtime.TabIndex = 142;
            this.lxLed_runtime.Text = "0";
            this.lxLed_runtime.TextAlignment = LxControl.LxLedControl.Alignment.Right;
            this.lxLed_runtime.TotalCharCount = 10;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(775, 270);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(71, 12);
            this.label26.TabIndex = 141;
            this.label26.Text = "Test Count:";
            // 
            // lxLed_epccount
            // 
            this.lxLed_epccount.BackColor = System.Drawing.Color.Transparent;
            this.lxLed_epccount.BackColor_1 = System.Drawing.Color.Transparent;
            this.lxLed_epccount.BackColor_2 = System.Drawing.Color.DarkRed;
            this.lxLed_epccount.BevelRate = 0.5F;
            this.lxLed_epccount.BorderColor = System.Drawing.Color.Lavender;
            this.lxLed_epccount.BorderWidth = 3;
            this.lxLed_epccount.FadedColor = System.Drawing.SystemColors.ControlLight;
            this.lxLed_epccount.FocusedBorderColor = System.Drawing.Color.LightCoral;
            this.lxLed_epccount.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lxLed_epccount.HighlightOpaque = ((byte)(50));
            this.lxLed_epccount.Location = new System.Drawing.Point(897, 200);
            this.lxLed_epccount.Name = "lxLed_epccount";
            this.lxLed_epccount.RoundCorner = true;
            this.lxLed_epccount.ShowHighlight = true;
            this.lxLed_epccount.Size = new System.Drawing.Size(121, 22);
            this.lxLed_epccount.TabIndex = 140;
            this.lxLed_epccount.Text = "0";
            this.lxLed_epccount.TextAlignment = LxControl.LxLedControl.Alignment.Right;
            this.lxLed_epccount.TotalCharCount = 10;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(775, 237);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(83, 12);
            this.label24.TabIndex = 139;
            this.label24.Text = "Run Time(ms):";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(775, 205);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(65, 12);
            this.label23.TabIndex = 137;
            this.label23.Text = "EPC Count:";
            // 
            // txt_maxscantime
            // 
            this.txt_maxscantime.Location = new System.Drawing.Point(897, 151);
            this.txt_maxscantime.Name = "txt_maxscantime";
            this.txt_maxscantime.Size = new System.Drawing.Size(121, 21);
            this.txt_maxscantime.TabIndex = 136;
            this.txt_maxscantime.Text = "10";
            this.txt_maxscantime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_scancount_KeyPress);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(775, 156);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(119, 12);
            this.label21.TabIndex = 135;
            this.label21.Text = "Max Scan Time(Sec):";
            // 
            // txt_testepccount
            // 
            this.txt_testepccount.Location = new System.Drawing.Point(897, 124);
            this.txt_testepccount.Name = "txt_testepccount";
            this.txt_testepccount.Size = new System.Drawing.Size(121, 21);
            this.txt_testepccount.TabIndex = 134;
            this.txt_testepccount.Text = "200";
            this.txt_testepccount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_scancount_KeyPress);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(775, 129);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(95, 12);
            this.label22.TabIndex = 133;
            this.label22.Text = "Test Tag Count:";
            // 
            // txt_scaninterval
            // 
            this.txt_scaninterval.Location = new System.Drawing.Point(897, 98);
            this.txt_scaninterval.Name = "txt_scaninterval";
            this.txt_scaninterval.Size = new System.Drawing.Size(121, 21);
            this.txt_scaninterval.TabIndex = 132;
            this.txt_scaninterval.Text = "1";
            this.txt_scaninterval.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_scancount_KeyPress);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(775, 103);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(119, 12);
            this.label20.TabIndex = 131;
            this.label20.Text = "Scan Interval(Sec):";
            // 
            // txt_scancount
            // 
            this.txt_scancount.Location = new System.Drawing.Point(897, 73);
            this.txt_scancount.Name = "txt_scancount";
            this.txt_scancount.Size = new System.Drawing.Size(121, 21);
            this.txt_scancount.TabIndex = 130;
            this.txt_scancount.Text = "100";
            this.txt_scancount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_scancount_KeyPress);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(775, 76);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(71, 12);
            this.label18.TabIndex = 129;
            this.label18.Text = "Scan Count:";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            this.dataGridView2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(6, 129);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(746, 387);
            this.dataGridView2.TabIndex = 122;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(897, 16);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(121, 38);
            this.button7.TabIndex = 121;
            this.button7.Text = "Clear";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(770, 17);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(121, 38);
            this.button8.TabIndex = 120;
            this.button8.Text = "Start";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.comboBox4);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.button5);
            this.groupBox3.Controls.Add(this.button6);
            this.groupBox3.Controls.Add(this.comboBox3);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.comboBox2);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Location = new System.Drawing.Point(8, 76);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(744, 59);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Impinj Inventory Mode Parameter";
            // 
            // comboBox4
            // 
            this.comboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "None",
            "TID",
            "Partial EPC",
            "Full EPC"});
            this.comboBox4.Location = new System.Drawing.Point(444, 22);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(117, 20);
            this.comboBox4.TabIndex = 16;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(415, 26);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(23, 12);
            this.label10.TabIndex = 15;
            this.label10.Text = "ID:";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(656, 21);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 14;
            this.button5.Text = "Get";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(576, 21);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 13;
            this.button6.Text = "Set";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // comboBox3
            // 
            this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "None",
            "Parity",
            "CRC5",
            "CRC5+"});
            this.comboBox3.Location = new System.Drawing.Point(270, 22);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(117, 20);
            this.comboBox3.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(200, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 12);
            this.label9.TabIndex = 2;
            this.label9.Text = "Protection:";
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "ID32",
            "ID16",
            "StoredCRC",
            "RN16"});
            this.comboBox2.Location = new System.Drawing.Point(38, 22);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(117, 20);
            this.comboBox2.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 26);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(23, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "CR:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Location = new System.Drawing.Point(8, 11);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(744, 59);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Reader Profile";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(653, 21);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 12;
            this.button3.Text = "Get";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(573, 21);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 11;
            this.button4.Text = "Set";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "123:PR-ASK,Tari20 ,PIE2,BLF320Khz,Miller2",
            "124:PR-ASK,Tari7.5,PIE2,BLF640Khz,Miller2",
            "141:PR-ASK,Tari20 ,PIE2,BLF320Khz,Miller4",
            "146:PR-ASK,Tari20 ,PIE2,BLF250Khz,Miller4",
            "148:PR-ASK,Tari7.5,PIE2,BLF640Khz,Miller4",
            "185:PR-ASK,Tari20 ,PIE2,BLF160Khz,Miller8",
            "4123:PR-ASK,Tari20 ,PIE2,BLF320Khz,BPSK2",
            "4124:PR-ASK,Tari7.5,PIE2,BLF640Khz,BPSK2",
            "4141:PR-ASK,Tari20 ,PIE2,BLF320Khz,BPSK4",
            "4146:PR-ASK,Tari20 ,PIE2,BLF250Khz,BPSK4",
            "4148:PR-ASK,Tari7.5,PIE2,BLF640Khz,BPSK4",
            "4185:PR-ASK,Tari20 ,PIE2,BLF160Khz,BPSK8",
            "5123:PR-ASK,Tari20 ,PIE2,BLF320Khz,M+B",
            "5124:PR-ASK,Tari7.5,PIE2,BLF640Khz,M+B",
            "5141:PR-ASK,Tari20 ,PIE2,BLF320Khz,M+B",
            "5146:PR-ASK,Tari20 ,PIE2,BLF250Khz,M+B",
            "5148:PR-ASK,Tari7.5,PIE2,BLF640Khz,M+B",
            "5185:PR-ASK,Tari20 ,PIE2,BLF160Khz,M+B"});
            this.comboBox1.Location = new System.Drawing.Point(62, 23);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(500, 20);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 26);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "Modes:";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.txt_authdata);
            this.tabPage3.Controls.Add(this.txt_challenge);
            this.tabPage3.Controls.Add(this.button15);
            this.tabPage3.Controls.Add(this.label208);
            this.tabPage3.Controls.Add(this.label207);
            this.tabPage3.Controls.Add(this.com_epc1);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Location = new System.Drawing.Point(4, 21);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1080, 520);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Authenticate";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // txt_authdata
            // 
            this.txt_authdata.Enabled = false;
            this.txt_authdata.Location = new System.Drawing.Point(205, 127);
            this.txt_authdata.Name = "txt_authdata";
            this.txt_authdata.ReadOnly = true;
            this.txt_authdata.Size = new System.Drawing.Size(478, 21);
            this.txt_authdata.TabIndex = 11;
            // 
            // txt_challenge
            // 
            this.txt_challenge.Enabled = false;
            this.txt_challenge.Location = new System.Drawing.Point(207, 81);
            this.txt_challenge.Name = "txt_challenge";
            this.txt_challenge.ReadOnly = true;
            this.txt_challenge.Size = new System.Drawing.Size(476, 21);
            this.txt_challenge.TabIndex = 10;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(606, 174);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(77, 23);
            this.button15.TabIndex = 9;
            this.button15.Text = "Auth";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // label208
            // 
            this.label208.AutoSize = true;
            this.label208.Location = new System.Drawing.Point(131, 84);
            this.label208.Name = "label208";
            this.label208.Size = new System.Drawing.Size(65, 12);
            this.label208.TabIndex = 8;
            this.label208.Text = "Challenge:";
            // 
            // label207
            // 
            this.label207.AutoSize = true;
            this.label207.Location = new System.Drawing.Point(77, 130);
            this.label207.Name = "label207";
            this.label207.Size = new System.Drawing.Size(119, 12);
            this.label207.TabIndex = 7;
            this.label207.Text = "Challenge Response:";
            // 
            // com_epc1
            // 
            this.com_epc1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.com_epc1.FormattingEnabled = true;
            this.com_epc1.Location = new System.Drawing.Point(207, 34);
            this.com_epc1.Name = "com_epc1";
            this.com_epc1.Size = new System.Drawing.Size(476, 20);
            this.com_epc1.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(143, 37);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 12);
            this.label15.TabIndex = 0;
            this.label15.Text = "EPCList:";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox6);
            this.tabPage4.Controls.Add(this.groupBox4);
            this.tabPage4.Location = new System.Drawing.Point(4, 21);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1080, 520);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Protected Mode";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.com_epc2);
            this.groupBox6.Controls.Add(this.label16);
            this.groupBox6.Controls.Add(this.txt_pro_password);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.button11);
            this.groupBox6.Controls.Add(this.button12);
            this.groupBox6.Location = new System.Drawing.Point(144, 144);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(710, 60);
            this.groupBox6.TabIndex = 90;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Tag Protected Mode Setting";
            // 
            // com_epc2
            // 
            this.com_epc2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.com_epc2.FormattingEnabled = true;
            this.com_epc2.Location = new System.Drawing.Point(64, 27);
            this.com_epc2.Name = "com_epc2";
            this.com_epc2.Size = new System.Drawing.Size(277, 20);
            this.com_epc2.TabIndex = 17;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(5, 30);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 12);
            this.label16.TabIndex = 16;
            this.label16.Text = "EPCList:";
            // 
            // txt_pro_password
            // 
            this.txt_pro_password.Location = new System.Drawing.Point(415, 26);
            this.txt_pro_password.MaxLength = 8;
            this.txt_pro_password.Name = "txt_pro_password";
            this.txt_pro_password.Size = new System.Drawing.Size(100, 21);
            this.txt_pro_password.TabIndex = 15;
            this.txt_pro_password.Text = "12345678";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(352, 30);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(59, 12);
            this.label17.TabIndex = 14;
            this.label17.Text = "Password:";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(620, 24);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(77, 23);
            this.button11.TabIndex = 11;
            this.button11.Text = "Disable";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(526, 24);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(77, 23);
            this.button12.TabIndex = 10;
            this.button12.Text = "Enable";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.checkBox4);
            this.groupBox4.Controls.Add(this.text_pro_pwd);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.rb_pro_en);
            this.groupBox4.Controls.Add(this.rb_pro_disabe);
            this.groupBox4.Controls.Add(this.button9);
            this.groupBox4.Controls.Add(this.button10);
            this.groupBox4.Location = new System.Drawing.Point(144, 73);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(710, 65);
            this.groupBox4.TabIndex = 89;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Reader Protected Mode Setting";
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Checked = true;
            this.checkBox4.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox4.Location = new System.Drawing.Point(393, 30);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(48, 16);
            this.checkBox4.TabIndex = 32;
            this.checkBox4.Text = "Save";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // text_pro_pwd
            // 
            this.text_pro_pwd.Location = new System.Drawing.Point(240, 28);
            this.text_pro_pwd.MaxLength = 8;
            this.text_pro_pwd.Name = "text_pro_pwd";
            this.text_pro_pwd.Size = new System.Drawing.Size(100, 21);
            this.text_pro_pwd.TabIndex = 13;
            this.text_pro_pwd.Text = "12345678";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(176, 32);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(59, 12);
            this.label19.TabIndex = 12;
            this.label19.Text = "Password:";
            // 
            // rb_pro_en
            // 
            this.rb_pro_en.AutoSize = true;
            this.rb_pro_en.Checked = true;
            this.rb_pro_en.Location = new System.Drawing.Point(96, 30);
            this.rb_pro_en.Name = "rb_pro_en";
            this.rb_pro_en.Size = new System.Drawing.Size(59, 16);
            this.rb_pro_en.TabIndex = 11;
            this.rb_pro_en.TabStop = true;
            this.rb_pro_en.Text = "Enable";
            this.rb_pro_en.UseVisualStyleBackColor = true;
            // 
            // rb_pro_disabe
            // 
            this.rb_pro_disabe.AutoSize = true;
            this.rb_pro_disabe.Location = new System.Drawing.Point(14, 30);
            this.rb_pro_disabe.Name = "rb_pro_disabe";
            this.rb_pro_disabe.Size = new System.Drawing.Size(65, 16);
            this.rb_pro_disabe.TabIndex = 10;
            this.rb_pro_disabe.Text = "Disable";
            this.rb_pro_disabe.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(620, 27);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(77, 23);
            this.button9.TabIndex = 9;
            this.button9.Text = "Get";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(526, 27);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(77, 23);
            this.button10.TabIndex = 8;
            this.button10.Text = "Set";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // comboBox5
            // 
            this.comboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "A",
            "B",
            "A|B"});
            this.comboBox5.Location = new System.Drawing.Point(856, 126);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(59, 20);
            this.comboBox5.TabIndex = 109;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(796, 130);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 12);
            this.label14.TabIndex = 108;
            this.label14.Text = "Target:";
            // 
            // StatusBar1
            // 
            this.StatusBar1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.StatusBar1.Location = new System.Drawing.Point(0, 702);
            this.StatusBar1.Name = "StatusBar1";
            this.StatusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
            this.TStatusPanel,
            this.Port,
            this.Manufacturername});
            this.StatusBar1.ShowPanels = true;
            this.StatusBar1.Size = new System.Drawing.Size(1088, 20);
            this.StatusBar1.SizingGrip = false;
            this.StatusBar1.TabIndex = 111;
            this.StatusBar1.Text = "StatusBar1";
            // 
            // TStatusPanel
            // 
            this.TStatusPanel.Name = "TStatusPanel";
            this.TStatusPanel.Width = 740;
            // 
            // Port
            // 
            this.Port.MinWidth = 66;
            this.Port.Name = "Port";
            this.Port.Text = "Port:";
            // 
            // Manufacturername
            // 
            this.Manufacturername.Name = "Manufacturername";
            this.Manufacturername.Text = "statusManufacturer nameBarPanel1";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.gpb_DBM);
            this.tabPage5.Location = new System.Drawing.Point(4, 21);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1080, 520);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Power Setting";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // gpb_DBM
            // 
            this.gpb_DBM.Controls.Add(this.button14);
            this.gpb_DBM.Controls.Add(this.label11);
            this.gpb_DBM.Controls.Add(this.ComboBox_PowerDbm);
            this.gpb_DBM.Controls.Add(this.BT_DBM);
            this.gpb_DBM.Location = new System.Drawing.Point(343, 138);
            this.gpb_DBM.Name = "gpb_DBM";
            this.gpb_DBM.Size = new System.Drawing.Size(437, 52);
            this.gpb_DBM.TabIndex = 30;
            this.gpb_DBM.TabStop = false;
            this.gpb_DBM.Text = "Power";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(157, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(23, 12);
            this.label11.TabIndex = 25;
            this.label11.Text = "dBm";
            // 
            // ComboBox_PowerDbm
            // 
            this.ComboBox_PowerDbm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_PowerDbm.FormattingEnabled = true;
            this.ComboBox_PowerDbm.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33"});
            this.ComboBox_PowerDbm.Location = new System.Drawing.Point(51, 17);
            this.ComboBox_PowerDbm.Name = "ComboBox_PowerDbm";
            this.ComboBox_PowerDbm.Size = new System.Drawing.Size(100, 20);
            this.ComboBox_PowerDbm.TabIndex = 24;
            // 
            // BT_DBM
            // 
            this.BT_DBM.Location = new System.Drawing.Point(233, 17);
            this.BT_DBM.Name = "BT_DBM";
            this.BT_DBM.Size = new System.Drawing.Size(90, 23);
            this.BT_DBM.TabIndex = 23;
            this.BT_DBM.Text = "Set";
            this.BT_DBM.UseVisualStyleBackColor = true;
            this.BT_DBM.Click += new System.EventHandler(this.BT_DBM_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(335, 17);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(90, 23);
            this.button14.TabIndex = 26;
            this.button14.Text = "Get";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.groupBox11);
            this.tabPage6.Controls.Add(this.comboBox_EPC);
            this.tabPage6.Controls.Add(this.label34);
            this.tabPage6.Location = new System.Drawing.Point(4, 21);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1080, 520);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Read/Write Tag";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.textBox_pc);
            this.groupBox11.Controls.Add(this.checkBox_pc);
            this.groupBox11.Controls.Add(this.btWrite);
            this.groupBox11.Controls.Add(this.btRead);
            this.groupBox11.Controls.Add(this.text_WriteData);
            this.groupBox11.Controls.Add(this.text_AccessCode2);
            this.groupBox11.Controls.Add(this.text_RWlen);
            this.groupBox11.Controls.Add(this.text_WordPtr);
            this.groupBox11.Controls.Add(this.label12);
            this.groupBox11.Controls.Add(this.label13);
            this.groupBox11.Controls.Add(this.label30);
            this.groupBox11.Controls.Add(this.label33);
            this.groupBox11.Controls.Add(this.groupBox12);
            this.groupBox11.Location = new System.Drawing.Point(13, 43);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(1055, 119);
            this.groupBox11.TabIndex = 20;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Read Data / Write Data / Block Erase";
            // 
            // textBox_pc
            // 
            this.textBox_pc.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.textBox_pc.Location = new System.Drawing.Point(616, 57);
            this.textBox_pc.Name = "textBox_pc";
            this.textBox_pc.ReadOnly = true;
            this.textBox_pc.Size = new System.Drawing.Size(138, 21);
            this.textBox_pc.TabIndex = 29;
            this.textBox_pc.Text = "0800";
            // 
            // checkBox_pc
            // 
            this.checkBox_pc.AutoSize = true;
            this.checkBox_pc.Location = new System.Drawing.Point(405, 59);
            this.checkBox_pc.Name = "checkBox_pc";
            this.checkBox_pc.Size = new System.Drawing.Size(162, 16);
            this.checkBox_pc.TabIndex = 28;
            this.checkBox_pc.Text = "Auto Compute and add PC";
            this.checkBox_pc.UseVisualStyleBackColor = true;
            this.checkBox_pc.CheckedChanged += new System.EventHandler(this.checkBox_pc_CheckedChanged);
            // 
            // btWrite
            // 
            this.btWrite.Location = new System.Drawing.Point(861, 55);
            this.btWrite.Name = "btWrite";
            this.btWrite.Size = new System.Drawing.Size(77, 23);
            this.btWrite.TabIndex = 12;
            this.btWrite.Text = "Write";
            this.btWrite.UseVisualStyleBackColor = true;
            this.btWrite.Click += new System.EventHandler(this.btWrite_Click);
            // 
            // btRead
            // 
            this.btRead.Location = new System.Drawing.Point(770, 55);
            this.btRead.Name = "btRead";
            this.btRead.Size = new System.Drawing.Size(77, 23);
            this.btRead.TabIndex = 11;
            this.btRead.Text = "Read";
            this.btRead.UseVisualStyleBackColor = true;
            this.btRead.Click += new System.EventHandler(this.btRead_Click);
            // 
            // text_WriteData
            // 
            this.text_WriteData.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.text_WriteData.Location = new System.Drawing.Point(529, 20);
            this.text_WriteData.Name = "text_WriteData";
            this.text_WriteData.Size = new System.Drawing.Size(504, 21);
            this.text_WriteData.TabIndex = 10;
            this.text_WriteData.Text = "0000";
            // 
            // text_AccessCode2
            // 
            this.text_AccessCode2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.text_AccessCode2.Location = new System.Drawing.Point(205, 87);
            this.text_AccessCode2.MaxLength = 8;
            this.text_AccessCode2.Name = "text_AccessCode2";
            this.text_AccessCode2.Size = new System.Drawing.Size(118, 21);
            this.text_AccessCode2.TabIndex = 9;
            this.text_AccessCode2.Text = "00000000";
            // 
            // text_RWlen
            // 
            this.text_RWlen.Location = new System.Drawing.Point(205, 57);
            this.text_RWlen.MaxLength = 2;
            this.text_RWlen.Name = "text_RWlen";
            this.text_RWlen.Size = new System.Drawing.Size(117, 21);
            this.text_RWlen.TabIndex = 8;
            this.text_RWlen.Text = "4";
            // 
            // text_WordPtr
            // 
            this.text_WordPtr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.text_WordPtr.Location = new System.Drawing.Point(205, 19);
            this.text_WordPtr.MaxLength = 4;
            this.text_WordPtr.Name = "text_WordPtr";
            this.text_WordPtr.Size = new System.Drawing.Size(117, 21);
            this.text_WordPtr.TabIndex = 7;
            this.text_WordPtr.Text = "0000";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(402, 23);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(131, 12);
            this.label12.TabIndex = 5;
            this.label12.Text = "Read/Write data(Hex):";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(7, 91);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(89, 12);
            this.label13.TabIndex = 4;
            this.label13.Text = "Password:(Hex)";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(6, 61);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(77, 12);
            this.label30.TabIndex = 3;
            this.label30.Text = "Length(Dec):";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(6, 23);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(125, 12);
            this.label33.TabIndex = 2;
            this.label33.Text = "Start address:(Hex):";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.C_User);
            this.groupBox12.Controls.Add(this.C_TID);
            this.groupBox12.Controls.Add(this.C_EPC);
            this.groupBox12.Controls.Add(this.C_Reserve);
            this.groupBox12.Location = new System.Drawing.Point(402, 81);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(259, 31);
            this.groupBox12.TabIndex = 1;
            this.groupBox12.TabStop = false;
            // 
            // C_User
            // 
            this.C_User.AutoSize = true;
            this.C_User.Location = new System.Drawing.Point(207, 11);
            this.C_User.Name = "C_User";
            this.C_User.Size = new System.Drawing.Size(47, 16);
            this.C_User.TabIndex = 3;
            this.C_User.Text = "User";
            this.C_User.UseVisualStyleBackColor = true;
            this.C_User.CheckedChanged += new System.EventHandler(this.C_EPC_CheckedChanged);
            // 
            // C_TID
            // 
            this.C_TID.AutoSize = true;
            this.C_TID.Location = new System.Drawing.Point(144, 11);
            this.C_TID.Name = "C_TID";
            this.C_TID.Size = new System.Drawing.Size(41, 16);
            this.C_TID.TabIndex = 2;
            this.C_TID.Text = "TID";
            this.C_TID.UseVisualStyleBackColor = true;
            this.C_TID.CheckedChanged += new System.EventHandler(this.C_EPC_CheckedChanged);
            // 
            // C_EPC
            // 
            this.C_EPC.AutoSize = true;
            this.C_EPC.Checked = true;
            this.C_EPC.Location = new System.Drawing.Point(81, 11);
            this.C_EPC.Name = "C_EPC";
            this.C_EPC.Size = new System.Drawing.Size(41, 16);
            this.C_EPC.TabIndex = 1;
            this.C_EPC.TabStop = true;
            this.C_EPC.Text = "EPC";
            this.C_EPC.UseVisualStyleBackColor = true;
            this.C_EPC.CheckedChanged += new System.EventHandler(this.C_EPC_CheckedChanged);
            // 
            // C_Reserve
            // 
            this.C_Reserve.AutoSize = true;
            this.C_Reserve.Location = new System.Drawing.Point(4, 11);
            this.C_Reserve.Name = "C_Reserve";
            this.C_Reserve.Size = new System.Drawing.Size(65, 16);
            this.C_Reserve.TabIndex = 0;
            this.C_Reserve.Text = "Reserve";
            this.C_Reserve.UseVisualStyleBackColor = true;
            this.C_Reserve.CheckedChanged += new System.EventHandler(this.C_EPC_CheckedChanged);
            // 
            // comboBox_EPC
            // 
            this.comboBox_EPC.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_EPC.FormattingEnabled = true;
            this.comboBox_EPC.Location = new System.Drawing.Point(87, 17);
            this.comboBox_EPC.Name = "comboBox_EPC";
            this.comboBox_EPC.Size = new System.Drawing.Size(345, 20);
            this.comboBox_EPC.TabIndex = 19;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label34.Location = new System.Drawing.Point(20, 21);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(59, 12);
            this.label34.TabIndex = 18;
            this.label34.Text = "Tag list:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1088, 722);
            this.Controls.Add(this.StatusBar1);
            this.Controls.Add(this.comboBox5);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.com_S);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.com_Q);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gpb_rs232);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RoyalRay Gen2 Extensions Demo";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.LocationChanged += new System.EventHandler(this.Form1_LocationChanged);
            this.gpb_rs232.ResumeLayout(false);
            this.gpb_rs232.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lxLedControl4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLedControl3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLedControl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLedControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox66.ResumeLayout(false);
            this.groupBox66.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lxLed_avgtime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLed_maxtuntime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLed_lostcount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLed_testcount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLed_runtime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lxLed_epccount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TStatusPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Port)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Manufacturername)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.gpb_DBM.ResumeLayout(false);
            this.gpb_DBM.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gpb_rs232;
        private System.Windows.Forms.Button btDisConnect232;
        private System.Windows.Forms.Button btConnect232;
        private System.Windows.Forms.ComboBox ComboBox_baud2;
        private System.Windows.Forms.Label label47;
        internal System.Windows.Forms.ComboBox ComboBox_COM;
        internal System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkant4;
        private System.Windows.Forms.CheckBox checkant3;
        private System.Windows.Forms.CheckBox checkant2;
        private System.Windows.Forms.CheckBox checkant1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox com_S;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.ComboBox com_Q;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label6;
        private LxControl.LxLedControl lxLedControl4;
        private System.Windows.Forms.Button button2;
        private LxControl.LxLedControl lxLedControl3;
        private System.Windows.Forms.Label label5;
        private LxControl.LxLedControl lxLedControl2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private LxControl.LxLedControl lxLedControl1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox66;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TextBox txt_authdata;
        private System.Windows.Forms.TextBox txt_challenge;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label label208;
        private System.Windows.Forms.Label label207;
        private System.Windows.Forms.ComboBox com_epc1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txt_pro_password;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.TextBox text_pro_pwd;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.RadioButton rb_pro_en;
        private System.Windows.Forms.RadioButton rb_pro_disabe;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.ComboBox com_epc2;
        private System.Windows.Forms.Label label16;
        internal System.Windows.Forms.StatusBar StatusBar1;
        private System.Windows.Forms.StatusBarPanel TStatusPanel;
        private System.Windows.Forms.StatusBarPanel Port;
        private System.Windows.Forms.StatusBarPanel Manufacturername;
        private System.Windows.Forms.TextBox txt_scaninterval;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txt_scancount;
        private System.Windows.Forms.Label label18;
        private LxControl.LxLedControl lxLed_testcount;
        private System.Windows.Forms.Label label25;
        private LxControl.LxLedControl lxLed_runtime;
        private System.Windows.Forms.Label label26;
        private LxControl.LxLedControl lxLed_epccount;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txt_maxscantime;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txt_testepccount;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label29;
        private LxControl.LxLedControl lxLed_maxtuntime;
        private System.Windows.Forms.Label label27;
        private LxControl.LxLedControl lxLed_lostcount;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label txt_success_rate;
        private LxControl.LxLedControl lxLed_avgtime;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox gpb_DBM;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox ComboBox_PowerDbm;
        private System.Windows.Forms.Button BT_DBM;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TextBox textBox_pc;
        private System.Windows.Forms.CheckBox checkBox_pc;
        private System.Windows.Forms.Button btWrite;
        private System.Windows.Forms.Button btRead;
        private System.Windows.Forms.TextBox text_WriteData;
        private System.Windows.Forms.TextBox text_AccessCode2;
        private System.Windows.Forms.TextBox text_RWlen;
        private System.Windows.Forms.TextBox text_WordPtr;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.RadioButton C_User;
        private System.Windows.Forms.RadioButton C_TID;
        private System.Windows.Forms.RadioButton C_EPC;
        private System.Windows.Forms.RadioButton C_Reserve;
        private System.Windows.Forms.ComboBox comboBox_EPC;
        private System.Windows.Forms.Label label34;
    }
}

