﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using UHF;
using System.Threading;
using System.Runtime.InteropServices;
using UHFReaderModule;
namespace Gen2ExtensionsDemo
{
    public partial class Form1 : Form
    {

        [DllImport("User32.dll", EntryPoint = "PostMessage")]
        private static extern int PostMessage(
        IntPtr hWnd, // handle to destination window 
        uint Msg, // message 
        uint wParam, // first message parameter 
        uint lParam // second message parameter 
        );

        [DllImport("User32.dll", EntryPoint = "SendMessage")]
        private static extern int SendMessage(IntPtr hwnd, int wMsg, IntPtr wParam, string lParam);

        [DllImport("User32.dll", EntryPoint = "FindWindow")]
        private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        public const int USER = 0x0400;
        public const int WM_SENDTAG = USER + 101;
        public const int WM_SENDTAG2 = USER + 102;
        public const int WM_SENDSTATU = USER + 103;
        public const int WM_SENDBUFF = USER + 104;
        public const int WM_MIXTAG = USER + 105;
        public const int WM_SHOWNUM = USER + 106;
        public const int WM_FASTID = USER + 107;


        public static UHFReader RWDev = new UHFReader();
        List<RFIDTag> curList = new List<RFIDTag>();
        private static object LockFlag = new object();
        List<string> epclist = new List<string>();
        RFIDCallBack elegateRFIDCallBack;
        byte fComAdr = 255;
        int fCmdRet = 0x30;
        bool reflasg = false;
        int total_tagnum = 0;

        public Form1()
        {
            InitializeComponent();
            elegateRFIDCallBack = new RFIDCallBack(GetUid);
        }

        public void GetUid(RFIDTag mtag)
        {
            lock (LockFlag)
            {
                curList.Add(mtag);
                total_tagnum++;
                CardNum++;
            }
        }

        private string GetReturnCodeDesc(int cmdRet)
        {
            switch (cmdRet)
            {
                case 0x00:
                    return "successfully";
                case 0x01:
                    return "Return before Inventory finished";
                case 0x02:
                    return "the Inventory-scan-time overflow";
                case 0x03:
                    return "More Data";
                case 0x04:
                    return "Reader module MCU is Full";
                case 0x05:
                    return "Access Password Error";
                case 0x09:
                    return "Destroy Password Error";
                case 0x0a:
                    return "Destroy Password Error Cannot be Zero";
                case 0x0b:
                    return "Tag Not Support the command";
                case 0x0c:
                    return "Use the commmand,Access Password Cannot be Zero";
                case 0x0d:
                    return "Tag is protected,cannot set it again";
                case 0x0e:
                    return "Tag is unprotected,no need to reset it";
                case 0x10:
                    return "There is some locked bytes,write fail";
                case 0x11:
                    return "can not lock it";
                case 0x12:
                    return "is locked,cannot lock it again";
                case 0x13:
                    return "Parameter Save Fail,Can Use Before Power";
                case 0x14:
                    return "Cannot adjust";
                case 0x15:
                    return "Return before Inventory finished";
                case 0x16:
                    return "Inventory-Scan-Time overflow";
                case 0x17:
                    return "More Data";
                case 0x18:
                    return "Reader module MCU is full";
                case 0x19:
                    return "'Not Support Command Or AccessPassword Cannot be Zero";
                case 0xFA:
                    return "Get Tag,Poor Communication,Inoperable";
                case 0xFB:
                    return "No Tag Operable";
                case 0xFC:
                    return "Tag Return ErrorCode";
                case 0xFD:
                    return "Command length wrong";
                case 0xFE:
                    return "Illegal command";
                case 0xFF:
                    return "Parameter Error";
                case 0x30:
                    return "Communication error";
                case 0x31:
                    return "CRC checksummat error";
                case 0x32:
                    return "Return data length error";
                case 0x33:
                    return "Communication busy";
                case 0x34:
                    return "Busy,command is being executed";
                case 0x35:
                    return "ComPort Opened";
                case 0x36:
                    return "ComPort Closed";
                case 0x37:
                    return "Invalid Handle";
                case 0x38:
                    return "Invalid Port";
                case 0xEE:
                    return "Return Command Error";
                default:
                    return "";
            }
        }
        private string GetErrorCodeDesc(int cmdRet)
        {
            switch (cmdRet)
            {
                case 0x00:
                    return "Other error";
                case 0x03:
                    return "Memory out or pc not support";
                case 0x04:
                    return "Memory Locked and unwritable";
                case 0x0b:
                    return "No Power,memory write operation cannot be executed";
                case 0x0f:
                    return "Not Special Error,tag not support special errorcode";
                default:
                    return "";
            }
        }
        private void AddCmdLog(string CMD, string cmdStr, int cmdRet)
        {
            try
            {
                StatusBar1.Panels[0].Text = "";
                StatusBar1.Panels[0].Text = DateTime.Now.ToLongTimeString() + " " +
                                            cmdStr + ": " +
                                            GetReturnCodeDesc(cmdRet);
            }
            finally
            {
                ;
            }
        }
        private void AddCmdLog(string CMD, string cmdStr, int cmdRet, int errocode)
        {
            try
            {
                StatusBar1.Panels[0].Text = "";
                StatusBar1.Panels[0].Text = DateTime.Now.ToLongTimeString() + " " +
                                            cmdStr + ": " +
                                            GetReturnCodeDesc(cmdRet) + " " + "0x" + Convert.ToString(errocode, 16).PadLeft(2, '0');
            }
            finally
            {
                ;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ComboBox_COM.SelectedIndex = 0;
            ComboBox_baud2.SelectedIndex = 4;
            groupBox1.Enabled = false;
            groupBox66.Enabled = false;
            button1.Enabled = false;
            com_Q.SelectedIndex = 4;
            com_S.SelectedIndex = 1;

            comboBox2.SelectedIndex = 1;
            comboBox3.SelectedIndex = 0;
            comboBox4.SelectedIndex = 0;
            comboBox1.SelectedIndex = 3;
            comboBox5.SelectedIndex = 0;

            ComboBox_PowerDbm.SelectedIndex = 28;
        }

         protected override void DefWndProc(ref Message m)
        {
            if (m.Msg == WM_SENDTAG)
            {

                string tagInfo = Marshal.PtrToStringAnsi(m.LParam);
                string[] btArr = tagInfo.Split(',');
                string sEPC;
                string str_ant = btArr[0];
                sEPC = btArr[2];
                string str_epclen = btArr[1]; ;
                byte epclen = Convert.ToByte(str_epclen, 10);
                string RSSI = btArr[3];
                int phase_begin = Convert.ToInt32(btArr[4], 10);
                int phase_end = Convert.ToInt32(btArr[5], 10);
                int freqkhz = Convert.ToInt32(btArr[6], 10);
                updateEPC(sEPC, RSSI, str_ant, phase_begin, phase_end, freqkhz);
                bool flagset = false;
                flagset = (dataGridView1.DataSource == null) ? true : false;
                dataGridView1.DataSource = dt;

                if (flagset)
                {
                    dataGridView1.Columns["Column1"].HeaderText = "NO.";
                    dataGridView1.Columns["Column1"].Width = 60;
                    dataGridView1.Columns["Column2"].HeaderText = "EPC";
                    dataGridView1.Columns["Column2"].Width = 180;
                    dataGridView1.Columns["Column3"].HeaderText = "Count1";
                    dataGridView1.Columns["Column3"].Width = 60;
                    dataGridView1.Columns["Column4"].HeaderText = "RSSI1";
                    dataGridView1.Columns["Column4"].Width = 60;
                    dataGridView1.Columns["Column5"].HeaderText = "Disale Quieting Read Time";
                    dataGridView1.Columns["Column5"].Width = 180;
                    dataGridView1.Columns["Column6"].HeaderText = "Count2";
                    dataGridView1.Columns["Column6"].Width = 60;
                    dataGridView1.Columns["Column7"].HeaderText = "RSSI2";
                    dataGridView1.Columns["Column7"].Width = 60;
                    dataGridView1.Columns["Column8"].HeaderText = "Enable Quieting Read Time";
                    dataGridView1.Columns["Column8"].Width = 180;
  
                }
            }
            else if (m.Msg == WM_SENDTAG2)
            {

                string tagInfo = Marshal.PtrToStringAnsi(m.LParam);
                string[] btArr = tagInfo.Split(',');
                string sEPC;
                string str_ant = btArr[0];
                sEPC = btArr[2];
                string str_epclen = btArr[1]; ;
                byte epclen = Convert.ToByte(str_epclen, 10);
                string RSSI = btArr[3];
                int phase_begin = Convert.ToInt32(btArr[4], 10);
                int phase_end = Convert.ToInt32(btArr[5], 10);
                int freqkhz = Convert.ToInt32(btArr[6], 10);
                updateEPC2(sEPC, RSSI, str_ant, phase_begin, phase_end, freqkhz);
                bool flagset = false;
                flagset = (dataGridView2.DataSource == null) ? true : false;
                dataGridView2.DataSource = dt;

                if (flagset)
                {
                    dataGridView2.Columns["Column1"].HeaderText = "NO.";
                    dataGridView2.Columns["Column1"].Width = 60;
                    dataGridView2.Columns["Column2"].HeaderText = headText;
                    dataGridView2.Columns["Column2"].Width = 520;
                    dataGridView2.Columns["Column3"].HeaderText = "Count";
                    dataGridView2.Columns["Column3"].Width = 60;
                    dataGridView2.Columns["Column4"].HeaderText = "RSSI";
                    dataGridView2.Columns["Column4"].Width = 60;


                }
            }
            else
                base.DefWndProc(ref m);
        }

         DataTable dt = null;
         private void updateEPC(string sEPC, string RSSI, string str_ant, int phase_begin, int phase_end, int freqkhz)
         {
             if (roundList.IndexOf(sEPC) == -1)
             {
                 roundList.Add(sEPC);
                 
             }
             if (epclist.Count == 0)
             {
                 epclist.Add(sEPC);
                 com_epc1.Items.Add(sEPC);
                 com_epc2.Items.Add(sEPC);
                 comboBox_EPC.Items.Add(sEPC);
                 dt = dataGridView1.DataSource as DataTable;
                 dt = new DataTable();
                 dt.Columns.Add("Column1", Type.GetType("System.String"));
                 dt.Columns.Add("Column2", Type.GetType("System.String"));
                 dt.Columns.Add("Column3", Type.GetType("System.String"));
                 dt.Columns.Add("Column4", Type.GetType("System.String"));
                 dt.Columns.Add("Column5", Type.GetType("System.String"));
                 dt.Columns.Add("Column6", Type.GetType("System.String"));
                 dt.Columns.Add("Column7", Type.GetType("System.String"));
                 dt.Columns.Add("Column8", Type.GetType("System.String"));
                 DataRow dr = dt.NewRow();
                 dr["Column1"] = (dt.Rows.Count + 1).ToString();
                 dr["Column2"] = sEPC;
                 if (InvType == 0)
                 {
                     dr["Column3"] = "1";
                     dr["Column4"] = RSSI;
                     dr["Column5"] = System.Environment.TickCount - beginTime + "";//只显示最早得到EPC的命令轮数
                     //dr["Column6"] = "";
                 }
                 else
                 {
                     dr["Column6"] = "1";
                     dr["Column7"] = RSSI;
                     dr["Column8"] = System.Environment.TickCount - beginTime + "";//只显示最早得到EPC的命令轮数
                 }
                 
                 dt.Rows.Add(dr);

             }
             else
             {
                 int index = epclist.IndexOf(sEPC);
                 if (index == -1)
                 {
  
                     epclist.Add(sEPC);
                     com_epc1.Items.Add(sEPC);
                     com_epc2.Items.Add(sEPC);
                     comboBox_EPC.Items.Add(sEPC);
                     DataRow dr2 = dt.NewRow();
                     dr2["Column1"] = (dt.Rows.Count + 1).ToString();
                     dr2["Column2"] = sEPC;
                     if (InvType == 0)
                     {
                         dr2["Column3"] = "1";
                         dr2["Column4"] = RSSI;
                         dr2["Column5"] = System.Environment.TickCount - beginTime + "";//只显示最早得到EPC的命令轮数
   
                     }
                     else
                     {
                         dr2["Column6"] = "1";
                         dr2["Column7"] = RSSI;
                         dr2["Column8"] = System.Environment.TickCount - beginTime + "";//只显示最早得到EPC的命令轮数
                     }
                     
                     dt.Rows.Add(dr2);
                 }
                 else
                 {
                     DataRow dr = dt.Rows[index];
                     if (InvType == 0)
                     {
                         int cnt = 0;
                         if (dr["Column3"] == null || dr["Column3"].ToString() == "")
                         {
                             cnt = 0;
                         }
                         else
                         {
                             cnt = int.Parse(dr["Column3"].ToString());
                         }
                         cnt++;
                         dt.Rows[index]["Column3"] = cnt.ToString();
                         dt.Rows[index]["Column4"] = RSSI;
                         if (dt.Rows[index]["Column5"].ToString() == "")
                             dt.Rows[index]["Column5"] = System.Environment.TickCount - beginTime + "";//只显示最早得到EPC的命令轮数
                     }
                     else
                     {
                         int cnt=0;
                         if (dr["Column6"] == null || dr["Column6"].ToString() == "")
                         {
                             cnt=0;
                         }
                         else
                         {
                             cnt = int.Parse(dr["Column6"].ToString());
                         }
                         
                         cnt++;
                         dt.Rows[index]["Column6"] = cnt.ToString();
                         dt.Rows[index]["Column7"] = RSSI;
                         if (dt.Rows[index]["Column8"].ToString() == "")
                             dt.Rows[index]["Column8"] = System.Environment.TickCount - beginTime + "";//只显示最早得到EPC的命令轮数
                     }
                 }
             }

         }


         private void updateEPC2(string sEPC, string RSSI, string str_ant, int phase_begin, int phase_end, int freqkhz)
         {
             //if (roundList.IndexOf(sEPC) == -1)
             //{
             //    roundList.Add(sEPC);
             //}
             if (epclist.Count == 0)
             {
                 epclist.Add(sEPC);
                 com_epc1.Items.Add(sEPC);
                 com_epc2.Items.Add(sEPC);
                 comboBox_EPC.Items.Add(sEPC);
                 dt = dataGridView2.DataSource as DataTable;
                 dt = new DataTable();
                 dt.Columns.Add("Column1", Type.GetType("System.String"));
                 dt.Columns.Add("Column2", Type.GetType("System.String"));
                 dt.Columns.Add("Column3", Type.GetType("System.String"));
                 dt.Columns.Add("Column4", Type.GetType("System.String"));
                 DataRow dr = dt.NewRow();
                 dr["Column1"] = (dt.Rows.Count + 1).ToString();
                 dr["Column2"] = sEPC;
                 dr["Column3"] = "1";
                 dr["Column4"] = RSSI;

                 dt.Rows.Add(dr);

             }
             else
             {
                 int index = epclist.IndexOf(sEPC);
                 if (index == -1)
                 {
                     com_epc1.Items.Add(sEPC);
                     com_epc2.Items.Add(sEPC);
                     comboBox_EPC.Items.Add(sEPC);
                     epclist.Add(sEPC);
                     DataRow dr2 = dt.NewRow();
                     dr2["Column1"] = (dt.Rows.Count + 1).ToString();
                     dr2["Column2"] = sEPC;
                     dr2["Column3"] = "1";
                     dr2["Column4"] = RSSI;

                     dt.Rows.Add(dr2);
                 }
                 else
                 {
                     DataRow dr = dt.Rows[index];
                     int cnt = 0;
                     if (dr["Column3"] == null || dr["Column3"].ToString() == "")
                     {
                         cnt = 0;
                     }
                     else
                     {
                         cnt = int.Parse(dr["Column3"].ToString());
                     }
                     cnt++;
                     dt.Rows[index]["Column3"] = cnt.ToString();
                     dt.Rows[index]["Column4"] = RSSI;
                 }
             }
             if ((epclist.Count >= TestTagCount) && (TargetSuccess==false))
             {
                 TargetSuccess = true;
                 RunTime = System.Environment.TickCount - RundStart;
                 RWDev.StopImmediately(ref fComAdr);
             }

         }
        private void btConnect232_Click(object sender, EventArgs e)
        {
            int portNum = ComboBox_COM.SelectedIndex + 1;
            string strException = string.Empty;
            byte fBaud = Convert.ToByte(ComboBox_baud2.SelectedIndex);
            if (fBaud > 2)
                fBaud = Convert.ToByte(fBaud + 2);
            fComAdr = 255;//广播地址打开设备
            fCmdRet = RWDev.OpenComPort(portNum, ref fComAdr, fBaud);
            if (fCmdRet != 0)
            {
                return;
            }
            else
            {
                tabControl1.Enabled = true;
                groupBox1.Enabled = true;
                groupBox66.Enabled = true;
                button1.Enabled = true;
                btConnect232.Enabled = false;
                btDisConnect232.Enabled = true;
                RWDev.InitRFIDCallBack(elegateRFIDCallBack);
                button18_Click(null,null);
                button3_Click(null, null);
                button5_Click(null, null);
            }
        }

        private void btDisConnect232_Click(object sender, EventArgs e)
        {
            if (button1.Text.Equals("Stop"))
            {
                return;
            }
            if (RWDev.isConnect)
            {
                RWDev.CloseComPort();
                groupBox1.Enabled = false;
                groupBox66.Enabled = false;
                button1.Enabled = false;
                btConnect232.Enabled = true;
                btDisConnect232.Enabled = false;
                tabControl1.Enabled = false;
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            byte enFlag = 1;
            if (radioButton1.Checked) 
                enFlag = 1;
            else
                enFlag = 0;

            enFlag |= 0x02;//匹配B
            byte cfgNo = 24;
            byte[] cfgData = new byte[256];
            int len = 1;
            cfgData[0] = (byte)enFlag;
            int fCmdRet = RWDev.SetCfgParameter(ref fComAdr, 0, cfgNo, cfgData, len);
            AddCmdLog("SetCfgParameter","Set",fCmdRet);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            byte cfgNo = 24;
            byte[] cfgData = new byte[256];
            int len = 0;
            int fCmdRet = RWDev.GetCfgParameter(ref fComAdr, cfgNo, cfgData, ref len);
            if (fCmdRet != 0)
            {

            }
            else
            {
                if (len == 1)
                {
                    if ((cfgData[0]&0x01) == 0)
                    {
                        radioButton2.Checked = true;
                    }
                    else
                    {
                        radioButton1.Checked = true;
                    }
                }
            }
            AddCmdLog("GetCfgParameter", "Get", fCmdRet);
        }

        byte[] antlist = new byte[4];
        long beginTime = 0;
        int SelectAntenna = 0;
        private volatile bool fIsInventoryScan = false;
        private volatile bool toStopThread = false;
        private Thread mythread = null;
        byte InAnt = 0x80;
        byte FastFlag = 1;
        byte Session = 1;
        byte QValue = 4;
        int AA_times = 0;
        byte Target = 0;
        byte RoundTarget = 0;
        int CardNum = 0;
        int CmdRound = 0;
        int InvType = 0;
        List<string> roundList = new List<string>();
        int functionTab = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text.Equals("Start"))
            {

                byte cfgNo = 24;
                byte[] cfgData = new byte[256];
                int len = 0;
                int fCmdRet = RWDev.GetCfgParameter(ref fComAdr, cfgNo, cfgData, ref len);
                if (fCmdRet==0)
                {
                    InvType = cfgData[0] &0x01;
                }
                RoundTarget = (byte)comboBox5.SelectedIndex;
                if (RoundTarget == 0 || RoundTarget == 2)
                    Target = 0;
                else
                    Target = 1;
                button1.Text = "Stop";
                groupBox1.Enabled = false;
                groupBox66.Enabled = false;
                com_Q.Enabled = false;
                com_S.Enabled = false;
                reflasg = false;
                curList.Clear();
                roundList.Clear();
                Array.Clear(antlist, 0, 4);
                
                QValue = (byte)com_Q.SelectedIndex;
                Session = (byte)com_S.SelectedIndex;
                SelectAntenna = 0;
                total_tagnum = 0;
                Target = 0;
                if (checkant1.Checked)
                {
                    antlist[0] = 1;
                    SelectAntenna |= 0x0001;
                }
                if (checkant2.Checked)
                {
                    antlist[1] = 1;
                    SelectAntenna |= 0x0002;
                }
                if (checkant3.Checked)
                {
                    antlist[2] = 1;
                    SelectAntenna |= 0x0004;
                }
                if (checkant4.Checked)
                {
                    antlist[3] = 1;
                    SelectAntenna |= 0x0008;
                }
                PresetTarget(Session, SelectAntenna);
                beginTime = System.Environment.TickCount;
                toStopThread = false;
                CmdRound = 1;
                functionTab = 0;
                if (fIsInventoryScan == false)
                {
                    mythread = new Thread(new ThreadStart(inventory));
                    mythread.IsBackground = true;
                    mythread.Start();
                    timer1.Enabled = true;
                }

            }
            else
            {
                toStopThread = true;
                fCmdRet = RWDev.StopImmediately(ref fComAdr);
                groupBox1.Enabled = true;
                groupBox66.Enabled = true;
                button1.Text = "Stoping";
                timer1.Enabled = false;
            }
        }

        public void PresetTarget(byte CurSession,int SelectAntenna)
        {
            if (CurSession == 0) return;
            byte MaskMem = 1;
            byte[] MaskAdr = new byte[2];
            byte MaskLen = 0;
            byte[] MaskData = new byte[100];
            byte MaskFlag = 0;
            byte Action = 0;
            if (Target == 0)
                Action = 0;
            else
                Action = 4;
            for (int m = 0; m < 4; m++)
            {
                fCmdRet = RWDev.SelectCMDByAntenna(ref fComAdr, SelectAntenna, 4, CurSession, Action, MaskMem, MaskAdr, MaskLen, MaskData, 0);
                Thread.Sleep(5);
            }
            if (CurSession == 1)
            {
                CurSession = 2;//复位S2
                for (int m = 0; m < 4; m++)
                {
                    fCmdRet = RWDev.SelectCMDByAntenna(ref fComAdr, SelectAntenna, 4, CurSession, Action, MaskMem, MaskAdr, MaskLen, MaskData, 0);
                    Thread.Sleep(5);
                }
            }
        }

        private void inventory()
        {
            fIsInventoryScan = true;
            while (!toStopThread)
            {
                try
                {
                    for (int m = 0; m < 4; m++)
                    {
                        if (toStopThread) break;
                        InAnt = (byte)(m | 0x80);
                        FastFlag = 1;
                        if (antlist[m] == 1)
                        {
                            if (Session > 1 && Session < 4 && RoundTarget==2)//s2,s3
                            {
                                if ( (AA_times + 1 > 4))
                                {
                                    Target = Convert.ToByte(1 - Target);  //如果连续2次未读到卡片，A/B状态切换。
                                    AA_times = 0;
                                }
                            }

                            flash_G2();
                            CmdRound++;
                        }
                    }
                    Thread.Sleep(5);
                }
                catch (System.Exception ex)
                {

                }
            }



            this.Invoke((EventHandler)delegate
            {
                if (fIsInventoryScan)
                {
                    toStopThread = true;//标志，接收数据线程判断stop为true，正常情况下会自动退出线程           

                   
                    fIsInventoryScan = false;
                }
                timer1.Enabled = false;
                com_Q.Enabled = true;
                com_S.Enabled = true;
                fIsInventoryScan = false;
                if (functionTab == 0)
                {
                    button1.Text = "Start";
                    button1.Enabled = true;
                    for (int m = 0; m < dataGridView1.Rows.Count; m++)
                    {
                        dataGridView1.Rows[m].Cells[3].Style.BackColor = Color.LightBlue;
                        dataGridView1.Rows[m].Cells[4].Style.BackColor = Color.LightBlue;
                        dataGridView1.Rows[m].Cells[5].Style.BackColor = Color.LightBlue;
                        dataGridView1.Rows[m].Cells[5].Style.BackColor = Color.Thistle;
                        dataGridView1.Rows[m].Cells[6].Style.BackColor = Color.Thistle;
                        dataGridView1.Rows[m].Cells[7].Style.BackColor = Color.Thistle;
                    }
                }
                else if (functionTab == 1)
                {
                    button8.Text = "Start";
                    button8.Enabled = true;
                }
                mythread = null;
                
            });

        }

        private int SetSession()
        {
            byte opt = 0x01;//不保存
            byte cfgNum = 0x09;
            byte[] data = new byte[256];
            int len = 2;
            data[0] = 3;//Q
            data[0] |= 0x10;//带相位
            data[1] = 0;//Session
            fCmdRet = RWDev.SetCfgParameter(ref fComAdr, opt, cfgNum, data, len);
            return fCmdRet;
        }
        private int SetAntenna()
        {
            byte ANT = 0;
            byte ANT1 = 0;
            byte SetOnce = 1;//不保存
            Array.Clear(antlist, 0, antlist.Length);
            if (checkant1.Checked)
            {
                ANT = Convert.ToByte(ANT | 0x01);
                antlist[0] = 1;
            }
            if (checkant2.Checked)
            {
                ANT = Convert.ToByte(ANT | 0x02);
                antlist[1] = 1;
            }
            if (checkant3.Checked)
            {
                ANT = Convert.ToByte(ANT | 0x04);
                antlist[2] = 1;
            }
            if (checkant4.Checked)
            {
                ANT = Convert.ToByte(ANT | 0x08);
                antlist[3] = 1;
            }

            fCmdRet = RWDev.SetAntennaMultiplexing(ref fComAdr, SetOnce, ANT1, ANT);
            return fCmdRet;
        }

        
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (reflasg) return;
            reflasg = true;
            updateAnswerMode();

            for (int m = 0; m < dataGridView1.Rows.Count; m++)
            {
                if (dataGridView1.Rows[m].Cells[3].Style.BackColor != Color.LightBlue)
                {
                    dataGridView1.Rows[m].Cells[3].Style.BackColor = Color.LightBlue;
                    dataGridView1.Rows[m].Cells[4].Style.BackColor = Color.LightBlue;
                    dataGridView1.Rows[m].Cells[5].Style.BackColor = Color.LightBlue;
                    dataGridView1.Rows[m].Cells[5].Style.BackColor = Color.Thistle;
                    dataGridView1.Rows[m].Cells[6].Style.BackColor = Color.Thistle;
                    dataGridView1.Rows[m].Cells[7].Style.BackColor = Color.Thistle;
                }
                
            }
            reflasg = false;
        }

        private int GetAntennaNumber(int ant)
        {
            int Antenna = 1;
            switch (ant)
            {
                case 0x01:
                    Antenna = 1;
                    break;
                case 0x02:
                    Antenna = 2;
                    break;
                case 0x04:
                    Antenna = 3;
                    break;
                case 0x08:
                    Antenna = 4;
                    break;
                case 0x10:
                    Antenna = 5;
                    break;
                case 0x20:
                    Antenna = 6;
                    break;
                case 0x40:
                    Antenna = 7;
                    break;
                case 0x80:
                    Antenna = 8;
                    break;
            }
            return Antenna;
        }


        private void flash_G2()
        {
            byte Ant = 0;
            int TagNum = 0;
            int Totallen = 0;
            byte[] EPC = new byte[50000];
            byte MaskMem = 0;
            byte[] MaskAdr = new byte[2];
            byte MaskLen = 0;
            byte[] MaskData = new byte[100];
            byte MaskFlag = 0;
            MaskFlag = 0;
            int cbtime = System.Environment.TickCount;
            CardNum = 0;
            MaskMem = 2;
            MaskAdr[0] = 0x00;
            MaskAdr[1] = 0x00;
            MaskLen = 16;
            MaskData[0] = 0xE2;
            MaskData[1] = 0x80;
            if ((functionTab == 0)&&(Session==1))
                MaskFlag = 1;
            else
                MaskFlag = 0;
            fCmdRet = RWDev.Inventory_G2(ref fComAdr, QValue, Session, MaskMem, MaskAdr, MaskLen, MaskData, MaskFlag, 0, 0, 0, Target, InAnt, 50, FastFlag, EPC, ref Ant, ref Totallen, ref TagNum);
            int cmdTime = System.Environment.TickCount - cbtime;//命令时间
            if (fCmdRet == 0x30)
            {
                CardNum = 0;
            }
            if (CardNum == 0)
            {
                if (Session > 1)
                    AA_times = AA_times + 1;//没有得到标签只更新状态栏
            }
            else
            {
                    AA_times = 0;
            }

            IntPtr ptrWnd1 = IntPtr.Zero;
            ptrWnd1 = FindWindow(null, "RoyalRay Gen2 Extensions Demo");
            if (ptrWnd1 != IntPtr.Zero)         // 检查当前统计窗口是否打开
            {
                string para = fCmdRet.ToString();
                SendMessage(ptrWnd1, WM_SENDSTATU, IntPtr.Zero, para);
            }
            ptrWnd1 = IntPtr.Zero;
        }


        private void updateAnswerMode()
        {
            IntPtr ptrWnd = IntPtr.Zero;
            ptrWnd = FindWindow(null, "RoyalRay Gen2 Extensions Demo");
            if (ptrWnd != IntPtr.Zero)         // 检查当前统计窗口是否打开
            {
                string para = fCmdRet.ToString();
                SendMessage(ptrWnd, WM_SHOWNUM, IntPtr.Zero, para);
            }

            RFIDTag[] mytag = new RFIDTag[500];
            int Count = 0;
            lock (LockFlag)
            {
                
                Count = curList.Count;
                if (Count > 0)
                {
                    curList.CopyTo(mytag, 0);
                }
                curList.Clear();
            }
            for (int p = 0; p < Count; p++)
            {
                RFIDTag mtag = mytag[p];
                SendTagMessage(ptrWnd, mtag);
            }
            if (functionTab == 0)
            {
                lxLedControl2.Text = total_tagnum + "";
                if (InvType == 0)
                    lxLedControl1.Text = roundList.Count + "";
                else
                    lxLedControl4.Text = roundList.Count + "";
                lxLedControl3.Text = System.Environment.TickCount - beginTime + "";
            }
            else if (functionTab == 1)
            {
                //lxLed_epccount.Text = total_tagnum + "";
                //lxLed_runtime.Text = 
                //lxLedControl6.Text = total_tagnum + "";
                //lxLedControl7.Text = epclist.Count + "";
                //lxLed_avgtime.Text = System.Environment.TickCount - beginTime + "";
            }
           
            ptrWnd = IntPtr.Zero;
        }


        private void SendTagMessage(IntPtr ptrWnd, RFIDTag ce)
        {
            if (mythread != null)
            {
                int Antnum = ce.ANT;
                string str_ant = GetAntennaNumber(Antnum).ToString();
                string epclen = ce.LEN.ToString();
                string para = str_ant + "," + epclen + "," + ce.UID + "," + ce.RSSI.ToString() + "," + ce.phase_begin + "," + ce.phase_end + "," + ce.Freqkhz;
                if (functionTab == 0)
                    SendMessage(ptrWnd, WM_SENDTAG, IntPtr.Zero, para);
                else if (functionTab == 1)
                    SendMessage(ptrWnd, WM_SENDTAG2, IntPtr.Zero, para);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            curList.Clear();
            epclist.Clear();
            lxLedControl1.Text = "0";
            lxLedControl4.Text = "0";
            lxLedControl2.Text = "0";
            lxLedControl3.Text = "0";
            com_epc1.Items.Clear();
            com_epc2.Items.Clear();
            comboBox_EPC.Items.Clear();
        }

        private void dataGridView1_Sorted(object sender, EventArgs e)
        {
            for (int m = 0; m < dataGridView1.Rows.Count; m++)
            {
                if (dataGridView1.Rows[m].Cells[3].Style.BackColor != Color.LightBlue)
                {
                    dataGridView1.Rows[m].Cells[3].Style.BackColor = Color.LightBlue;
                    dataGridView1.Rows[m].Cells[4].Style.BackColor = Color.LightBlue;
                    dataGridView1.Rows[m].Cells[5].Style.BackColor = Color.LightBlue;
                    dataGridView1.Rows[m].Cells[5].Style.BackColor = Color.Thistle;
                    dataGridView1.Rows[m].Cells[6].Style.BackColor = Color.Thistle;
                    dataGridView1.Rows[m].Cells[7].Style.BackColor = Color.Thistle;
                }

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string temp = comboBox1.Text;
            string[] file = temp.Split(':');
            if (file.Length!=2)
            {
                return;
            }
            int profile = Convert.ToInt32(file[0], 10);
            fCmdRet = RWDev.SetExtProfile(ref fComAdr, (byte)1, ref profile);
            AddCmdLog("", "Set", fCmdRet);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int profile = 0;
            fCmdRet = RWDev.SetExtProfile(ref fComAdr, (byte)0, ref profile);
            if (fCmdRet==0)
            {
                switch (profile)
                {
                    case 123:
                        comboBox1.SelectedIndex = 0;
                        break;
                    case 124:
                        comboBox1.SelectedIndex = 1;
                        break;
                    case 141:
                        comboBox1.SelectedIndex = 2;
                        break;
                    case 146:
                        comboBox1.SelectedIndex = 3;
                        break;
                    case 148:
                        comboBox1.SelectedIndex = 4;
                        break;
                    case 185:
                        comboBox1.SelectedIndex = 5;
                        break;
                    case 4123:
                        comboBox1.SelectedIndex = 6;
                        break;
                    case 4124:
                        comboBox1.SelectedIndex = 7;
                        break;
                    case 4141:
                        comboBox1.SelectedIndex = 8;
                        break;
                    case 4146:
                        comboBox1.SelectedIndex = 9;
                        break;
                    case 4148:
                        comboBox1.SelectedIndex = 10;
                        break;
                    case 4185:
                        comboBox1.SelectedIndex = 11;
                        break;
                    case 5123:
                        comboBox1.SelectedIndex = 12;
                        break;
                    case 5124:
                        comboBox1.SelectedIndex = 13;
                        break;
                    case 5141:
                        comboBox1.SelectedIndex = 14;
                        break;
                    case 5146:
                        comboBox1.SelectedIndex = 15;
                        break;
                    case 5148:
                        comboBox1.SelectedIndex = 16;
                        break;
                    case 5185:
                        comboBox1.SelectedIndex = 17;
                        break;
                }
            }
            AddCmdLog("", "Get", fCmdRet);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            byte CR = (byte)comboBox2.SelectedIndex;
            byte Prote = (byte)comboBox3.SelectedIndex;
            byte ID = (byte)comboBox4.SelectedIndex;
            byte cfgNo = 25;
            byte[] cfgData = new byte[256];
            int len = 3;
            cfgData[0] = (byte)CR;
            cfgData[1] = (byte)Prote;
            cfgData[2] = (byte)ID;
            int fCmdRet = RWDev.SetCfgParameter(ref fComAdr, 0, cfgNo, cfgData, len);
            if (fCmdRet != 0)
            {

            }
            else
            {

            }
            AddCmdLog("", "Set", fCmdRet);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            byte cfgNo = 25;
            byte[] cfgData = new byte[256];
            int len = 0;
            int fCmdRet = RWDev.GetCfgParameter(ref fComAdr, cfgNo, cfgData, ref len);
            if (fCmdRet != 0)
            {

            }
            else
            {
                if (len == 3)
                {
                    try {
                        comboBox2.SelectedIndex = cfgData[0];
                    comboBox3.SelectedIndex = cfgData[1];
                    comboBox4.SelectedIndex = cfgData[2];
                    if (cfgData[2] == 0)
                    {
                        headText = "ID16";
                    }
                    else
                    {
                        headText = "EPC";
                    }
                    }catch(Exception ex)
                    {}
                }
            }
            AddCmdLog("", "Get", fCmdRet);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            dataGridView2.DataSource = null;
            curList.Clear();
            epclist.Clear();
            lxLed_epccount.Text = "0";
            lxLed_runtime.Text = "0";
            lxLed_testcount.Text = "0";
            lxLed_lostcount.Text = "0";
            lxLed_avgtime.Text = "0";

            lxLed_maxtuntime.Text = "0";
            txt_success_rate.Text = "";

            com_epc1.Items.Clear();
            com_epc2.Items.Clear();
            comboBox_EPC.Items.Clear();
        }
        string headText = "EPC";

        int ScanCount = 0;
        int ScanInterval = 0;
        int TestTagCount = 0;
        int MaxScanTime = 0;

        int EPCCount = 0;
        int RunTime = 0;
        int TestCount = 0;
        int LostCount = 0;
        int AvgTime = 0;
        int MaxRunTime = 0;

        float Successrate = 0.0f;
        bool TargetSuccess = false;
        private void button8_Click(object sender, EventArgs e)
        {
            if (button8.Text.Equals("Start") && mythread==null)
            {
                if (txt_scancount.Text.Length == 0 || txt_scaninterval.Text.Length == 0 || txt_testepccount.Text.Length == 0 || txt_maxscantime.Text.Length == 0)
                {
                    return;
                }
                ScanCount = Convert.ToInt32(txt_scancount.Text, 10);
                ScanInterval = Convert.ToInt32(txt_scaninterval.Text, 10);
                TestTagCount = Convert.ToInt32(txt_testepccount.Text, 10);
                MaxScanTime = Convert.ToInt32(txt_maxscantime.Text, 10);

                button8.Text = "Stop";
                groupBox2.Enabled = false;
                groupBox3.Enabled = false;
                com_Q.Enabled = false;
                com_S.Enabled = false;
                reflasg = false;
                curList.Clear();
                roundList.Clear();
                Array.Clear(antlist, 0, 4);
                RoundTarget = (byte)comboBox5.SelectedIndex;
                if (RoundTarget == 0 || RoundTarget == 2)
                    Target = 0;
                else
                    Target = 1;
                QValue = (byte)com_Q.SelectedIndex;
                Session = (byte)com_S.SelectedIndex;
                SelectAntenna = 0;
                total_tagnum = 0;
                Target = 0;
                functionTab = 1;
                if (checkant1.Checked)
                {
                    antlist[0] = 1;
                    SelectAntenna |= 0x0001;
                }
                if (checkant2.Checked)
                {
                    antlist[1] = 1;
                    SelectAntenna |= 0x0002;
                }
                if (checkant3.Checked)
                {
                    antlist[2] = 1;
                    SelectAntenna |= 0x0004;
                }
                if (checkant4.Checked)
                {
                    antlist[3] = 1;
                    SelectAntenna |= 0x0008;
                }
                PresetTarget(Session, SelectAntenna);
                beginTime = System.Environment.TickCount;
                toStopThread = false;
                CmdRound = 1;
                button5_Click(null,null);
                if (fIsInventoryScan == false)
                {
                    mythread = new Thread(new ThreadStart(ScanRound));
                    mythread.IsBackground = true;
                    mythread.Start();
                    timer1.Enabled = true;
                }

            }
            else
            {
                toStopThread = true;
                //fCmdRet = RWDev.StopImmediately(ref fComAdr);
                groupBox2.Enabled = true;
                groupBox3.Enabled = true;
                com_Q.Enabled = true;
                com_S.Enabled = true;
                button8.Text = "Start";
                timer1.Enabled = false;
            }
        }


        private int RundStart = 0;
        public class TagRound
        {
            public int Round;
            public int RunTime;
            public int TagCount;
        }

        List<TagRound> rList = new List<TagRound>();
        private void ScanRound()
        {
            LostCount = 0;
            MaxRunTime = 0;
            AvgTime =0;
            int AVG = 0;
            for (int t = 0; t < ScanCount;t++ )//按次数读取
            {
                TargetSuccess = false;
                epclist.Clear();//存储当前一轮的标签
                rList.Clear();
                if (toStopThread == true) break;
                byte MaskMem = 1;
                byte[] MaskAdr = new byte[2];
                byte MaskLen = 0;
                byte[] MaskData = new byte[100];

                TagRound Rtag = new TagRound();
                Rtag.Round = t + 1;
                
                for (int n = 0; n < 8; n++)
                    fCmdRet = RWDev.SelectCmd(ref fComAdr, (byte)SelectAntenna, Session, (byte)0, MaskMem, MaskAdr, MaskLen,MaskData, (byte)0);
                RundStart = System.Environment.TickCount;
                while ((System.Environment.TickCount - RundStart)<MaxScanTime*1000)//最大询查时间
                {
                    try
                    {
                        for (int m = 0; m < 4; m++)
                        {
                            InAnt = (byte)(m | 0x80);
                            FastFlag = 1;
                            if (antlist[m] == 1)
                            {
                                if (Session > 1 && Session < 4 && RoundTarget == 2)//s2,s3
                                {
                                    if ((AA_times + 1 > 4))
                                    {
                                        Target = Convert.ToByte(1 - Target);  //如果连续2次未读到卡片，A/B状态切换。
                                        AA_times = 0;
                                    }
                                }

                                flash_G2();
                                CmdRound++;
                            }
                        }
                        Thread.Sleep(1);
                    }
                    catch (System.Exception ex)
                    {

                    }
                    if(epclist.Count>=TestTagCount)
                    {
                        break;
                    }
                }


                Rtag.RunTime = RunTime;
                Rtag.TagCount = epclist.Count;
                rList.Add(Rtag);
                if (epclist.Count < TestTagCount)
                    LostCount++;
                if(RunTime>MaxRunTime)
                {
                    MaxRunTime = RunTime;
                }
                AvgTime+=RunTime;
                AVG = AvgTime / (t + 1);
                this.Invoke((EventHandler)delegate
                {
                    lxLed_epccount.Text = epclist.Count+"";
                    lxLed_runtime.Text = RunTime+"";
                    lxLed_testcount.Text = (t + 1) + "";
                    lxLed_lostcount.Text = LostCount+"";

                    lxLed_avgtime.Text = AVG + "";
                    lxLed_maxtuntime.Text = MaxRunTime + "";
                });

                Thread.Sleep(ScanInterval * 1000);

            }

            this.Invoke((EventHandler)delegate
            {
                txt_success_rate.Text = ((100 - LostCount) * 100 / 100.00f) + "%";
                toStopThread = true;
                groupBox2.Enabled = true;
                groupBox3.Enabled = true;
                button8.Text = "Start";
                timer1.Enabled = false;
                com_Q.Enabled = true;
                com_S.Enabled = true;

            });

            mythread = null;

        }
        private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (mythread != null)
            {
                e.Cancel = true;
                MessageBox.Show("Stop thread first!!!");
                return;
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Random rdom = new Random();
            byte WordPtr, ENum;
            byte Num = 0;
            byte Mem = 0;
            string str = ""; ;
            byte[] CardData = new byte[320];
            byte MaskMem = 0;
            byte[] MaskAdr = new byte[2];
            byte MaskLen = 0;
            byte[] MaskData = new byte[100];
            str = com_epc1.Text;
            ENum = Convert.ToByte(str.Length / 4);

            byte[] EPC = new byte[ENum * 2];
            EPC = RWDev.HexStringToByteArray(str);
            byte[] fPassWord = RWDev.HexStringToByteArray("00000000");

            byte sendRep = 1;
            byte IncrepLen = 1;
            byte CSI = 1;
            byte MsgLen = 0x30;
            byte[] MsgData = new byte[6];
            for (int p = 0; p < 6; p++)
            {
                MsgData[p] = (byte)rdom.Next(0, 255);
            }
            MsgData[0] &= 0x03;
            MsgData[0] |= 0x04;
            txt_challenge.Text = RWDev.ByteArrayToHexString(MsgData);
            txt_authdata.Text = "";
            byte Auth_len = 0;
            int ferrorcode = 0;
            byte[] Auth_data = new byte[16];
            for (int p = 0; p < 10; p++)
            {
                fCmdRet = RWDev.Authenticate_G2(ref fComAdr, EPC, ENum, sendRep, IncrepLen, CSI, MsgLen, MsgData, fPassWord,
                                                    MaskMem, MaskAdr, MaskLen, MaskData, ref Auth_len, Auth_data, ref ferrorcode);
                if (fCmdRet == 0) break;
            }
            if (fCmdRet != 0)
            {
            }
            else
            {
                byte[] daw = new byte[Auth_len];
                Array.Copy(Auth_data, daw, Auth_len);
                txt_authdata.Text = RWDev.ByteArrayToHexString(daw);

            }
            AddCmdLog("Authenticate_G2", "Auth", fCmdRet);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            byte saved = 0;
            if (checkBox4.Checked)
                saved = 0;
            else
                saved = 1;
            byte enFlag = 1;
            if (rb_pro_disabe.Checked) enFlag = 0;
            else
                enFlag = 1;
            byte cfgNo = 14;
            byte[] cfgData = new byte[256];
            int len = 6;
            cfgData[0] = (byte)enFlag;
            byte[] Pwd = new byte[4];
            if (text_pro_pwd.Text.Length != 8)
            {
                return;
            }
            Pwd = RWDev.HexStringToByteArray(text_pro_pwd.Text);
            Array.Copy(Pwd, 0, cfgData, 1, 4);
            cfgData[5] = (byte)(cfgData[0] ^ cfgData[1] ^ cfgData[2] ^ cfgData[3] ^ cfgData[4]);
            int fCmdRet = RWDev.SetCfgParameter(ref fComAdr, saved, cfgNo, cfgData, len);
            AddCmdLog("", "Set", fCmdRet);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            byte cfgNo = 14;
            byte[] cfgData = new byte[256];
            int len = 0;
            int fCmdRet = RWDev.GetCfgParameter(ref fComAdr, cfgNo, cfgData, ref len);
            if (fCmdRet != 0)
            {
                
            }
            else
            {
                if (len == 6)
                {
                    if (cfgData[0] == 1)
                    {
                        rb_pro_en.Checked = true;
                    }
                    else
                    {
                        rb_pro_disabe.Checked = true;
                    }
                    byte[] daw = new byte[4];
                    Array.Copy(cfgData, 1, daw, 0, 4);
                    text_pro_pwd.Text = RWDev.ByteArrayToHexString(daw);
                }
            }
            AddCmdLog("", "Get", fCmdRet);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            string str = "";
            byte ENum;
            byte[] CardData = new byte[320];
            byte MaskMem = 0;
            byte[] MaskAdr = new byte[2];
            byte MaskLen = 0;
            byte[] MaskData = new byte[100];
            str = com_epc2.Text;
            ENum = Convert.ToByte(str.Length / 4);
            byte[] EPC = new byte[ENum * 2];
            EPC = RWDev.HexStringToByteArray(str);
            if (txt_pro_password.Text.Length != 8)
            {
                MessageBox.Show("Password Length error！", "Info");
                return;
            }
            byte[] fPassWord = RWDev.HexStringToByteArray(txt_pro_password.Text);
            int ferrorcode = 0;
            for (int m = 0; m < 10; m++)
            {
                fCmdRet = RWDev.Protected_mode_Enabled(ref fComAdr, EPC, ENum, fPassWord, MaskMem, MaskAdr, MaskLen, MaskData, ref ferrorcode);
                if (fCmdRet == 0) break;
            }

            if (fCmdRet != 0)
            {

                
            }
            else
            {

            }
            AddCmdLog("Protected_mode", "Enable", fCmdRet);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            string str = "";
            byte ENum;
            byte[] CardData = new byte[320];
            byte MaskMem = 0;
            byte[] MaskAdr = new byte[2];
            byte MaskLen = 0;
            byte[] MaskData = new byte[100];
            str = com_epc2.Text;
            ENum = Convert.ToByte(str.Length / 4);
            byte[] EPC = new byte[ENum * 2];
            EPC = RWDev.HexStringToByteArray(str);
            if (txt_pro_password.Text.Length != 8)
            {
                MessageBox.Show("Password Length error！", "Info");
                return;
            }
            byte[] fPassWord = RWDev.HexStringToByteArray(txt_pro_password.Text);

            int ferrorcode = 0;
            for (int m = 0; m < 10; m++)
            {
                fCmdRet = RWDev.Protected_mode_Disabled(ref fComAdr, EPC, ENum, fPassWord, MaskMem, MaskAdr, MaskLen, MaskData, ref ferrorcode);
                if (fCmdRet == 0) break;
            }
            if (fCmdRet != 0)
            {

            }
            else
            {

            }
            AddCmdLog("Protected_mode", "Disabled", fCmdRet);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex < 6)
            {
                comboBox2.Enabled = false;
                comboBox3.Enabled = false;
                comboBox4.Enabled = false;
            }
            else
            {
                comboBox2.Enabled = true;
                comboBox3.Enabled = true;
                comboBox4.Enabled = true;
            }
        }

        private void label25_Click(object sender, EventArgs e)
        {

        }

        private void lxLedControl10_Click(object sender, EventArgs e)
        {

        }

        private void txt_scancount_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = ("0123456789".IndexOf(Char.ToUpper(e.KeyChar)) < 0);
        }

        private void BT_DBM_Click(object sender, EventArgs e)
        {
            byte powerDbm = (byte)ComboBox_PowerDbm.SelectedIndex;
            fCmdRet = RWDev.SetRfPower(ref fComAdr, powerDbm);
            AddCmdLog("", "Set", fCmdRet);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            byte TrType = 0;
            byte[] VersionInfo = new byte[2];
            byte ReaderType = 0;
            byte ScanTime = 0;
            byte dmaxfre = 0;
            byte dminfre = 0;
            byte powerdBm = 0;
            byte FreBand = 0;
            byte AntCfg0 = 0;
            byte BeepEn = 0;
            byte AntCfg1 = 0;
            byte OutputRep = 0;
            byte CheckAnt = 0;
            fCmdRet = RWDev.GetReaderInformation(ref fComAdr, VersionInfo, ref ReaderType, ref TrType, ref dmaxfre, ref dminfre, ref powerdBm, ref ScanTime, ref AntCfg0, ref BeepEn, ref AntCfg1, ref CheckAnt);
            if (fCmdRet == 0)
            {
                if (powerdBm<34)
                    ComboBox_PowerDbm.SelectedIndex = powerdBm;
            }
            AddCmdLog("", "Get", fCmdRet);
        }

        private void btRead_Click(object sender, EventArgs e)
        {
            byte WordPtr, ENum;
            byte Num = 0;
            byte Mem = 0;
            string str = ""; ;
            byte[] CardData = new byte[320];
            byte MaskMem = 0;
            byte[] MaskAdr = new byte[2];
            byte MaskLen = 0;
            byte[] MaskData = new byte[100];
            text_WriteData.Text = "";
            str = comboBox_EPC.Text; ;
            ENum = Convert.ToByte(str.Length / 4);
            byte[] EPC = new byte[ENum * 2];
            EPC = RWDev.HexStringToByteArray(str);
            if (C_Reserve.Checked)
                Mem = 0;
            if (C_EPC.Checked)
                Mem = 1;
            if (C_TID.Checked)
                Mem = 2;
            if (C_User.Checked)
                Mem = 3;
            if (text_WordPtr.Text == "" || text_RWlen.Text == "" || text_AccessCode2.Text.Length != 8)
            {
                return;
            }
            WordPtr = (byte)Convert.ToInt32(text_WordPtr.Text, 16);
            Num = Convert.ToByte(text_RWlen.Text);
            byte[]fPassWord = RWDev.HexStringToByteArray(text_AccessCode2.Text);
            int ferrorcode = 0;
            for (int p = 0; p < 10; p++)
            {
                fCmdRet = RWDev.ReadData_G2(ref fComAdr, EPC, ENum, Mem, WordPtr, Num, fPassWord, MaskMem, MaskAdr, MaskLen, MaskData, CardData, ref ferrorcode);
                if (fCmdRet == 0) break;
            }
            if (fCmdRet == 0)
            {
                byte[] daw = new byte[Num * 2];
                Array.Copy(CardData, daw, Num * 2);
                text_WriteData.Text = RWDev.ByteArrayToHexString(daw);
            }
            AddCmdLog("ReadData_G2", "Read", fCmdRet);
        }

        private void btWrite_Click(object sender, EventArgs e)
        {
            byte WordPtr, ENum;
            byte WNum = 0;
            byte Mem = 0;
            string str = ""; ;
            byte[] CardData = new byte[320];
            byte MaskMem = 0;
            byte[] MaskAdr = new byte[2];
            byte MaskLen = 0;
            byte[] MaskData = new byte[100];
            str = comboBox_EPC.Text;
            ENum = Convert.ToByte(str.Length / 4);
            byte[] EPC = new byte[ENum * 2];
            EPC = RWDev.HexStringToByteArray(str);
            if (C_Reserve.Checked)
                Mem = 0;
            if (C_EPC.Checked)
                Mem = 1;
            if (C_TID.Checked)
                Mem = 2;
            if (C_User.Checked)
                Mem = 3;
            if (text_WordPtr.Text == "" || text_AccessCode2.Text.Length != 8)
            {
                return;
            }
            string epcstr = text_WriteData.Text;
            if (epcstr.Length % 4 != 0 || epcstr.Length == 0)
            {
                MessageBox.Show("Input data by word.", "Write");
                return;
            }
            WNum = Convert.ToByte(epcstr.Length / 4);
            byte[] Writedata = new byte[WNum * 2 + 1];
            Writedata = RWDev.HexStringToByteArray(epcstr);
            WordPtr = (byte)Convert.ToInt32(text_WordPtr.Text, 16);
            byte[] fPassWord = RWDev.HexStringToByteArray(text_AccessCode2.Text);
            if ((checkBox_pc.Checked) && (C_EPC.Checked))
            {
                WordPtr = 1;
                WNum = Convert.ToByte(epcstr.Length / 4 + 1);
                Writedata = RWDev.HexStringToByteArray(textBox_pc.Text + epcstr);
            }
            int ferrorcode = 0;
            for (int p = 0; p < 10; p++)
            {
                fCmdRet = RWDev.WriteData_G2(ref fComAdr, EPC, WNum, ENum, Mem, WordPtr, Writedata, fPassWord, MaskMem, MaskAdr, MaskLen, MaskData, ref ferrorcode);
                if (fCmdRet == 0) break;
            }
            AddCmdLog("WriteData_G2", "Write", fCmdRet);
        }

        private void checkBox_pc_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_pc.Checked && C_EPC.Checked)
            {
                text_WordPtr.Text = "0002";
                text_WordPtr.ReadOnly = true;
                int m, n;
                n = text_WriteData.Text.Length;
                if (n % 4 == 0)
                {
                    m = n / 4;
                    m = (m & 0x3F) << 3;
                    textBox_pc.Text = Convert.ToString(m, 16).PadLeft(2, '0') + "00";
                }
            }
            else
            {
                text_WordPtr.ReadOnly = false;
            }
        }

        private void C_EPC_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_pc.Checked)
            {
                text_WordPtr.Text = "0002";
                text_WordPtr.ReadOnly = true;
            }
            else
            {
                text_WordPtr.ReadOnly = false;
            }
        }

        private void Form1_LocationChanged(object sender, EventArgs e)
        {

        }


        //private void UpdateListView()
        //{
        //    RFIDTag[] mytag = new RFIDTag[500];
        //    int Count = 0;
        //    lock (LockFlag)
        //    {
        //        Count = curList.Count;
        //        if (Count > 0)
        //        {
        //            curList.CopyTo(mytag, 0);
        //        }
        //        curList.Clear();
        //    }
        //    for (int p = 0; p < Count; p++)
        //    {
        //        //RFIDTag mtag = mytag[p];
        //        //string[]temp = new string[9];
        //        //temp[0] = (listView1.Items.Count + 1) + "";
        //        //temp[1] = mtag.UID;
        //        //temp[2] = GetAntennaNumber(mtag.ANT) + "";
        //        //int rssi = 0;
        //        //if (mtag.RSSI != 0)
        //        //    rssi = mtag.RSSI - 130;
        //        //temp[3] = rssi + "";
        //        //temp[4] = mtag.Freqkhz + "";
        //        //temp[5] = String.Format("{0:N3}", mtag.phase_begin * 0.087f % 180);
        //        //temp[6] = String.Format("{0:N3}", mtag.phase_end * 0.087f % 180);
        //        //temp[7] = (mtag.tickCount)+"";
        //        //if (beginTime == 0)
        //        //    beginTime = mtag.tickCount; 
        //        //temp[8] = ((mtag.tickCount - beginTime))+"";
        //        //beginTime = mtag.tickCount;
        //        //ListViewItem items = new ListViewItem(temp);
        //        //listView1.Items.Add(items);
        //    }
        //}



    }
}
